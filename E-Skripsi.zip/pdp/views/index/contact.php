<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header">
        <h2 class="card-title"> <strong> <i class="fa fa-book" aria-hidden></i> Contact Us</strong> </h2>
      </div>
      <div class="card-body">
        <table class="table">
          <tr>
            <td>My Company</td>
            <td>:</td>
            <td> RN Studio </td>
          </tr>
          <tr>
            <td>Address</td>
            <td>:</td>
            <td> Jln. Prof. H.M. Yamin, SH. No. 173 Kisaran, Sumatera Utara </td>
          </tr>
          <tr>
            <td>Website</td>
            <td>:</td>
            <td> https://www.rnstudio.id </td>
          </tr>
          <tr>
            <td>Email</td>
            <td>:</td>
            <td> support@rnstudio.id </td>
          </tr>
          <tr>
            <td>Telp</td>
            <td>:</td>
            <td> 0623-43279 </td>
          </tr>
          <tr>
            <td>WA </td>
            <td>:</td>
            <td> 082391177785  </td>
          </tr>
          <tr>
            <td>Facebook </td>
            <td>:</td>
            <td> rnstudio  </td>
          </tr>
          <tr>
            <td>  Twitter</td>
            <td>:</td>
            <td> @rnstudioid  </td>
          </tr>
          <tr>
            <td>  Instagram</td>
            <td>:</td>
            <td> rnstudioid  </td>
          </tr>
        </table>

      </div>
    </div>
  </div>
</div>
