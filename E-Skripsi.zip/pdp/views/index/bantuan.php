<div class="row">
  <div class="col-lg-12 col-xs-12">
    Tutorial Penggunaan E-Skripsi :
    <br>
    <p>
      Untuk menggunakan sistem ini silahkan ikuti langkah-langkah yang ada didalam ebook yang bisa didownload dibawah. Didalam panduan ini akan dijelaskan secara detail aturan dan tata cara penggunaan aplikasi ini.
      <blockquote>
        Jika masih belum paham, dapat kirim pertanyaan ke support@rnstudio.id
      </blockquote>
    </p>

    <a href="?p=download" class="btn btn-success"> <i class="fa fa-download" aria-hidden></i> Download Ebook </a>

  </div>
</div>
