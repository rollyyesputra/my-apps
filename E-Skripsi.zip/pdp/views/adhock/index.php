<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <a href="?p=Adhock&x=Tambah" class="btn btn-info btn-flat">Tambah Tim</a>
    <br/>
    <br/>
    <table class="table table-bordered table-sm" id="dtskripsi">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nama</th>
          <th>NIDN</th>
          <th>Prodi</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $no=0;
        foreach ($data['tim'] as $value) {?>
          <tr>
            <td><?= ++$no ;?></td>
            <td><?= $value['Name'].", ".$value['Gelar'];?></td>
            <td><?= $value['NIDN'];?></td>
            <td><?= $value['prodi'] == 'SI' ? 'Sistem Informasi' : 'Sistem Komputer';?></td>
            <td>
              <a href="?p=Adhock&x=Edit&id=<?= $value['id'];?>" class="btn btn-info btn-sm btn-flat"><i class="fa fa-pencil"></i>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>
