<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <div class="row">
      <div class="col-sm-12 col-md-6">
        <table class="table">
          <tr>
            <th>Nama Dosen</th>
            <td>:</td>
            <td><?= $data['tim'][0]['Name'].", ".$data['tim'][0]['Gelar'];?></td>
          </tr>
           <tr>
            <th>Prodi</th>
            <td>:</td>
            <td><?= $data['tim'][0]['prodi'] == 'SI' ?'Sistem Informasi' : 'Sistem Komputer';?></td>
          </tr>
        </table>
        <br/>
      </div>
      <div class="col-sm-12">
<table class="table table-bordered table-sm" id="dtskripsi">
  <thead>
    <tr>
      <th>No.</th>
      <th>NIM</th>
      <th>Nama</th>
      <th>Judul</th>
      <th>Rekomendasi</th>
      <th>ACC</th>
      <th>Tahun</th>
    </tr>
  </thead>
  <tbody>
    <?php 
    $no=0;
    foreach ($data['judul'] as $row) { ?>
      <tr>
        <td><?= ++$no; ?></td>
        <td><?= $row['NIM'];?></td>
        <td><?= $row['Name'];?></td>
        <td><?= $row['judul'];?></td>
        <td><?= $row['rekomendasi'];?></td>
        <td><?= $row['status'];?></td>
        <td><?= $row['tahun'];?></td>
      </tr>
     <?php 
    }
    ?>
  </tbody>
</table>
      </div>
    </div>
  </div>
</div>