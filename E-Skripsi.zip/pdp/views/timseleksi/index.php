<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <a href="?p=Timseleksi&x=Tambah" class="btn btn-info"><i class='fa fa-plus'></i> <b>Tambah Tim</b></a>
    <br/>
    <br/>
    <table class="table table-bordered table-sm" id="dtskripsi">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nama</th>
          <th>NIDN</th>
          <th>Prodi</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $no=0;
        foreach ($data['tim'] as $value) {?>
          <tr>
            <td><?= ++$no ;?></td>
            <td><?= $value['Name'].", ".$value['Gelar'];?></td>
            <td><?= $value['NIDN'];?></td>
            <td><?= $value['prodi'] == 'SI' ? 'Sistem Informasi' : 'Sistem Komputer';?></td>
            <td align="center">
              <a href="?p=Timseleksi&x=Detail&id=<?= $value['id'];?>" class="btn btn-info btn-sm btn-flat"><i class="fa fa-folder-open-o"></i>
              <a href="?p=Timseleksi&x=Edit&id=<?= $value['id'];?>" class="btn btn-dark btn-sm btn-flat"><i class="fa fa-pencil"></i>
              <a href="?p=Timseleksi&x=Hapus&id=<?= $value['id'];?>" class="btn btn-danger btn-sm btn-flat"  onclick="return confirm('Yakin akan dihapus')"><i class="fa fa-trash"></i></a>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>
