<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form action="<?= $data['action'];?>" method="post">
      <input type="hidden" name="id" value="<?= $data['input']['id'];?>">
      <div class="form-group">
        <label>Username 
         </label>
        <input type="text" name="user_name" value="<?= $data['input']['user_name'];?>" class="form-control" placeholder="Username" maxlength="10">
         <?php 
          if(!empty($data['pesan'])){ ?>
            <div class="alert alert-danger"><?php echo $data['pesan']."</div>"; } ?>
      </div>
      <div class="form-group">
        <label>Nama</label>
        <input type="text" name="nama" value="<?= $data['input']['nama'];?>" class="form-control" placeholder="Nama">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="text" name="email" value="<?= $data['input']['email'];?>" class="form-control" placeholder="Email">
      </div>
      <div class="form-group">
        <label>Password</label>
        <?php 
        if($data['action'] == '?p=User&x=EditBiro' or $data['action'] == '?p=User&x=ProfilBiro'){ ?>
        <input type="hidden" name="pwdlama" value="<?= $data['input']['pwdlama'];?>" >
        <input type="password" name="password" value="" class="form-control" placeholder="Password">
        <?php }else{?>
        <input type="password" name="password" value="<?= $data['input']['password'];?>" class="form-control" placeholder="Password">
        <?php } ?>
      </div>
      <div class="form-group">
        <label>Tidak Aktif</label>&nbsp;&nbsp;&nbsp;
        <input type="checkbox" name="aktif" value="N" <?= $data['input']['aktif'] == 'N' ? 'checked' : '';?>>
      </div>
      <div class="form-group">
        <input type="submit" name="simpan" class="btn btn-info btn-flat" value="Simpan">
        <input type="reset" class="btn btn-success btn-flat" value="Reset">
        <?php if($sess->get('level') == 1){?>
        <a href="?p=User&x=Biro" class="btn btn-dark btn-flat">Batal</a>
        <?php } ?>
      </div>
    </form>
  </div>
</div>
