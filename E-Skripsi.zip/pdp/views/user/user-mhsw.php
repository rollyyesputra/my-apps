<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table class="table table-bordered table-hover table-striped table-sm" id="dtskripsi">
      <thead>
        <tr>
          <th>No.</th>
          <th>NIM</th>
          <th>Nama</th>
          <th>Login</th>
          <th>Email</th>
          <th>Tidak Aktif</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
         $no=0;
         //echo count($data['user']);
         foreach ($data['user'] as $value) {?>
          <tr>
            <td><?= ++$no ;?></td>
            <td><?= $value['NIM'];?></td>
            <td><?= $value['Name'];?></td>
            <td><?= $value['Login'];?></td>
            <td><?= $value['Email'];?></td>
            <td align="center"><?= $value['NotActive'];?></td>
            <td align="center">
              <a href="?p=User&x=EditMhsw&id=<?= $value['ID'] ;?>" class="btn btn-dark btn-sm btn-flat"><i class="fa fa-pencil"></i></a>
              <!--<a href="?p=User&x=HapusMhsw&id=<?= $value['ID'] ;?>&act=Mhsw" onclick="return confirm('Yakin akan menghapus user ini ?')" class="btn btn-danger btn-sm btn-flat"><i class="fa fa-trash"></i></a> -->
            </td>
          </tr>
           <?php
         }
         ?>
      </tbody>
    </table>
  </div>
</div>
