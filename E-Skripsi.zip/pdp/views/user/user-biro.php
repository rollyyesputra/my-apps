<a href="?p=User&x=TambahBiro" class="btn btn-outline-success"><strong> <i class="fa fa-user-plus"></i> Tambah User Biro</strong></a>
<br/>
<br/>
<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table class="table table-bordered table-hover table-striped table-sm" id="dtskripsi">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nama</th>
          <th>Login</th>
          <th>Email</th>
          <th>Aktif</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
         $no=0;
         //echo count($data['user']);
         foreach ($data['user'] as $value) {?>
          <tr>
            <td><?= ++$no ;?></td>
            <td><?= $value['nama'];?></td>
            <td><?= $value['user_name'];?></td>
            <td><?= $value['email'];?></td>
            <td align="center"><?= $value['aktif'];?></td>
            <td align="center">
              <a href="?p=User&x=EditBiro&id=<?= $value['id'] ;?>" class="btn btn-dark btn-sm btn-flat"><i class="fa fa-pencil"></i></a>
              <a href="?p=User&x=HapusUser&id=<?= $value['id'] ;?>&act=Biro" onclick="return confirm('Yakin akan menghapus user ini ?')" class="btn btn-danger btn-sm btn-flat"><i class="fa fa-trash"></i></a>
            </td>
          </tr>
           <?php
         }
         ?>
      </tbody>
    </table>
  </div>
</div>
