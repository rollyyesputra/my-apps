<?php      
$readonly = '';
if($sess->get('level') != 1){ 
  $readonly = 'readonly';
}
  ?>

<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form action="<?= $data['action'];?>" method="post">
      <input type="hidden" name="id" value="<?= $data['input']['ID'];?>">
      <div class="form-group">
        <label>Username 
         </label>
        <input type="text" name="user_name" value="<?= $data['input']['Login'];?>" class="form-control" placeholder="Username" maxlength="10" <?= $readonly ;?>>
         <?php 
          if(!empty($data['pesan'])){ ?>
            <div class="alert alert-danger"><?php echo $data['pesan']."</div>"; } ?>
      </div>
      <div class="form-group">
        <label>Nama</label>
        <input type="text" name="nama" value="<?= $data['input']['Name'];?>" class="form-control" placeholder="Nama" <?= $readonly ;?>>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="text" name="email" value="<?= $data['input']['Email'];?>" class="form-control" placeholder="Email">
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="hidden" name="pwdlama" value="<?= $data['input']['pwdlama'];?>" >
        <input type="password" name="password" value="" class="form-control" placeholder="Password">
      </div>
      <div class="form-group">
        <label>Tidak Aktif</label>&nbsp;&nbsp;&nbsp;
        <input type="checkbox" name="aktif" value="Y" <?= $data['input']['NotActive'] == 'Y' ? 'checked' : '';?>>
      </div>
      <div class="form-group">
        <input type="submit" name="simpan" class="btn btn-info btn-flat" value="Simpan">
        <?php 
        if($sess->get('level') == 1){ ?>
        <input type="reset" class="btn btn-success btn-flat" value="Reset">
        <a href="?p=User&x=Mahasiswa" class="btn btn-dark btn-flat">Batal</a>
        <?php }?>
      </div>
    </form>
  </div>
</div>
