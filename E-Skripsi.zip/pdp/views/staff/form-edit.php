<div class="card">
    <div class="card-header">
      <h5 class="card-title"><?= $data['sub_title'];?></h5>

      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-widget="collapse">
          <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
          <i class="fa fa-times"></i>
      </button>
  </div>
</div>
<!-- /.card-header -->
<div class="card-body">
  <form method="post" action="?p=Staff&x=SimpanEdit">
    <input type="hidden" name="ID" value="<?= $data['staff'][0]['IDStaff'] ;?>">
          <fieldset class="form-group">
            <label for="NIK">NIK</label>
            <input type="text" name="NIK" class="form-control" placeholder="NIK" value="<?= $data['staff'][0]['NIK'] ;?>" required>
            <small class="text-muted">Nomor Induk Kepegawaian</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Nama</label>
            <input type="text" class="form-control" name="Name" placeholder="Nama" value="<?= $data['staff'][0]['Nama'] ;?>" required>
            <small class="text-muted">Nama Lengkap</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Program Studi</label>
            <select class="form-control" name="Prodi" required="">
              <option value="">-Pilih-</option>
              <?php 
              foreach ($data['prodi'] as $value) {
                $value['Kode'] == $data['staff'][0]['KodeProdi'] ? $s = 'selected' : $s='';
                echo "<option value='".$value['Kode']."' $s > $value[Prodi]</option>";
              }
              ?>
            </select>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="Bagian">Bagian</label>
            <input type="text" class="form-control" name="Bagian" value="<?= $data['staff'][0]['Bagian'] ;?>" placeholder="Bagian" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Jenis Kelamin</label><br/>
            <input type="radio" name="Sex" value="L" <?= $data['staff'][0]['JenisKelamin'] == 'L' ? 'checked' : ''  ;?>>Laki laki<br/>
            <input type="radio" name="Sex" value="P" <?= $data['staff'][0]['JenisKelamin'] == 'P' ? 'checked' : ''  ;?>>Perempuan
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">Tanggal Lahir</label>
            <input type="text" class="form-control" name="TglLahir" value="<?= $data['staff'][0]['TglLahir'] ;?>" placeholder="YYYY-MM-DD" required>
            <small class="text-muted"></small>
          </fieldset>

<fieldset class="form-group">
            <label for="">Tempat Lahir</label>
            <input type="text" class="form-control" name="TempatLahir" placeholder="Tempat Lahir" value="<?= $data['staff'][0]['TempatLahir'] ;?>" required>
            <small class="text-muted"></small>
          </fieldset>

          <fieldset class="form-group">
            <label for="txtNamaLengkap">Alamat</label>
            <textarea name="Alamat" id="alamat" class="form-control" rows="8" cols="80" required><?= $data['staff'][0]['Alamat'] ;?></textarea>
            <small class="text-muted">Alamat lengkap mahasiswa</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="">No. Telepon</label>
            <input type="text" class="form-control" name="Phone" value="<?= $data['staff'][0]['Phone'] ;?>" placeholder="Nomor Telepon" required>
            <small class="text-muted"></small>
          </fieldset>

          <button type="submit" name="simpan" class="btn btn-success"> <i class="fa fa-save" aria-hidden></i> Simpan </button>
          <a href="?p=Staff" class="btn btn-danger"> <i class="fa fa-history

          " aria-hidden></i> Kembali</a>
        </form>
</div>
</div>