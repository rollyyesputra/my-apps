<div class="row">
  <div class="col-lg-12 col-xs-12">
    <div class="card">
      <div class="card-header">
        <h2 class="card-title"> <strong> <i class="fa fa-user-plus" aria-hidden></i> Update Data Staff Program Studi</strong> </h2>
      </div>
      <div class="card-body">
        <form method="post" action="?p=ProgramStudi&x=Edit">
          <input type="hidden" value="<?=$data[0]['id']?>" name="id">
          <fieldset class="form-group">
            <label for="nik">NIK</label>
            <input type="text" class="form-control" name="nik" id="nik" value="<?=$data[0]['nik']?>" placeholder="Nomor induk pegawai" autocomplete="off" required>
            <small class="text-muted">Nomor Induk Pegawai.</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="nama">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?=$data[0]['nama']?>" placeholder="Nama Lengkap" autocomplete="off" required>
            <small class="text-muted">Nama Lengkap.</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="jabatan">Bagian</label>
            <input type="text" class="form-control" id="bagian" name="bagian" value="<?=$data[0]['bagian']?>" placeholder="bagian" autocomplete="off" required>
            <small class="text-muted">Bagian sekarang.</small>
          </fieldset>

          <button type="submit" class="btn btn-info"> <i class="fa fa-save" aria-hidden></i> Update Data</button>
          <a href="?p=ProgramStudi" class="btn btn-warning"> <i class="fa fa-history" aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>
  </div>
</div>
