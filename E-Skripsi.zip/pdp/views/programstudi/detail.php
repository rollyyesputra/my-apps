<div class="row">
  <div class="col-md-12 col-xs-12">
    <h2 class="card-title"> <strong> &raquo; Detail Data <?=$_GET['p']?></strong> </h2>
    <table class="table">
      <tr>
        <td>NIK</td>
        <td>: <?=$data[0]['nik']?></td>
      </tr>
      <tr>
        <td>Nama</td>
        <td>: <?=$data[0]['nama']?></td>
      </tr>
      <tr>
        <td>Bagian</td>
        <td>: <?=$data[0]['bagian']?></td>
      </tr>
    </table>
    <a href="?p=ProgramStudi&x=Update&id=<?= $data[0]['id'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> Update</a>
    <a href="?p=ProgramStudi&x=Hapus&id=<?= $data[0]['id'] ?>" class="btn btn-outline-danger btn-sm"> <i class="fa fa-remove" aria-hidden></i> Remove </a>
    <a href="?p=ProgramStudi" class="btn btn-warning btn-sm"> <i class="fa fa-history" aria-hidden></i> Kembali </a>
  </div>
</div>
