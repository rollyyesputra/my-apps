<div class="card">
    <div class="card-header">
      <h5 class="card-title"><?= $data['sub_title'];?></h5>

      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-widget="collapse">
          <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
          <i class="fa fa-times"></i>
      </button>
  </div>
</div>
<!-- /.card-header -->
<div class="card-body">
        <form method="post" action="?p=ProgramStudi&x=edit">
          <input type="hidden" name="IDProdi" value="<?= $data['prodi'][0]['IDProdi'] ;?>">
          <fieldset class="form-group">
            <label for="Kode">Kode Program Studi</label>
            <input type="text" class="form-control" name="Kode" id="Kode" value="<?= $data['prodi'][0]['Kode'] ;?>" placeholder="Kode Program Studi" autocomplete="off" required>
            <small class="text-muted">Nomor Induk Pegawai.</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="Nama">Nama Program Studi</label>
            <input type="text" class="form-control" id="Nama" value="<?= $data['prodi'][0]['Prodi'] ;?>" name="Nama" placeholder="Nama Program Studi" autocomplete="off" required>
            <small class="text-muted">Nama Program Studi.</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="Fakultas">Fakultas</label>
            <input type="text" class="form-control" id="Fakultas" value="<?= $data['prodi'][0]['Fakultas'] ;?>" name="Fakultas" placeholder="Fakultas" autocomplete="off" required>
            <small class="text-muted">Fakultas</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="KaProdi">Nama Ka. Prodi</label>
            <input type="text" class="form-control" id="KaProdi" value="<?= $data['prodi'][0]['KaProdi'] ;?>" name="KaProdi" placeholder="Ka. Prodi Program Studi" autocomplete="off" required>
            <small class="text-muted">Ka. Prodi Program Studi.</small>
          </fieldset>

          <fieldset class="form-group">
            <label for="NIDN">NIDN Ka. Prodi</label>
            <input type="text" class="form-control" id="NIDN" value="<?= $data['prodi'][0]['NIDN'] ;?>" name="NIDN" placeholder="NIDN Ka. Prodi" autocomplete="off" required>
            <small class="text-muted">NIDN Ka. Prodi.</small>
          </fieldset>

          <button type="submit" name="simpan" class="btn btn-info"> <i class="fa fa-save" aria-hidden></i> Simpan</button>
          <a href="?p=ProgramStudi" class="btn btn-warning"> <i class="fa fa-history" aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>
