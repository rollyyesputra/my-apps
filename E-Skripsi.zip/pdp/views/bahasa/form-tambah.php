<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <form action="?p=Bahasa&x=AddBahasa" method="post" class="form-horizontal">
                  <div class="form-group">
                    <label for="Nama" class="col-sm-12 col-md-3 control-label">Bahasa Pemrograman</label>
                    <div class="col-sm-12 col-md-8">
                      <input type="text" name="Nama" class="form-control" required="">
                    </div>
                  </div>
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-info btn-flat" value="Simpan">
                    <a href="?p=Bahasa" class="btn btn-dark btn-flat">Batal</a>
                  </div>
               
              </form>
            </div>
          </div>
