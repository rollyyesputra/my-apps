<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
                <button type="button" class="btn btn-tool" data-widget="remove">
                  <i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <form action="?p=Tahun&x=addtahun" method="post" class="form-horizontal">
                  <div class="form-group">
                    <label for="Kode" class="col-sm-12 col-md-3 control-label">Kode Tahun</label>
                    <div class="col-sm-12 col-md-8">
                      <input type="text" name="Kode" class="form-control" placeholder="Kode Tahun" maxlength="5" required="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="TA" class="col-sm-12 col-md-3 control-label">Tahun Akademik</label>
                    <div class="col-sm-12 col-md-8">
                      <input type="text" name="TA" class="form-control" placeholder="Tahun Akademik" maxlength="9" required="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="Status" class="col-sm-12 col-md-3 control-label">Status</label>
                    <div class="col-sm-12 col-md-8">
                      <select name="Status" required="" class="form-control">
                        <option value="">-Pilih-</option>
                        <option value="Y">Aktif</option>
                        <option value="N">Tidak Aktif</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="TA" class="col-sm-12 col-md-3 control-label">Keterangan</label>
                    <div class="col-sm-12 col-md-8">
                      <textarea name="Ket" class="form-control" rows="3" placeholder="Keterangan"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-info btn-flat" value="Simpan">
                    <a href="?p=Tahun" class="btn btn-dark btn-flat">Batal</a>
                  </div>
               
              </form>
            </div>
          </div>
