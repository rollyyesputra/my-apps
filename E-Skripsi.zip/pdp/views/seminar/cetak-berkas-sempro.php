<?php 
if($data['mhsw'][0]['KodeJurusan']=="SI"){                  
	$prodi = "Sistem Informasi";
	$kpd = "William Ramdhan, M.Kom.";
	$NIDN ="0130048702";
	$homepage = "s1is.stmik.royal.ac.id";
	$email = "prodi_si@royal.ac.id";
	$logo = "images/si.png";
}else{ 
	$prodi = "Sistem Komputer";
	$kpd = "Muhammad Amin, M.Kom.";
	$NIDN ="0113128502";
	$homepage = "s1cs.stmik.royal.ac.id";
	$email = "prodi_sk@royal.ac.id";
	$logo = "images/sk.png";
}
?>

      <table width="100%">
        <tr>
         <td rowspan="" width="60">          
           <img src="<?= $logo ;?>" width="80" height="80"/>           
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $prodi ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>BERITA ACARA SEMINAR PROPOSAL SKRIPSI</u></strong></td>
      </tr>
    </table>
     <br/>
    <p>
    	Pada hari ini ................... tanggal ...... ......................... ......... telah dilaksanakan Seminar Proposal Skripsi atas nama mahasiswa dibawah ini :
    </p>
    <div style="margin-left:25px ; margin-right: 25px ">
    	<table width="100%">
    		<tr>
    			<td width="15%">Nama</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['Name'] ;?></td>
    		</tr>
    		<tr>
    			<td>NIM</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['NIM'] ;?></td>
    		</tr>
    		<tr>
    			<td>Program Studi</td>
    			<td>:</td>
    			<td><?= $prodi ;?></td>
    		</tr>
    		<tr>
    			<td>Judul Skripi</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['judul'] ;?></td>
    		</tr>
    	</table>
    	<p>Dengan Dosen Penguji sebagi berikut:</p>
    	<table border="1" width="100%">
    		<tr>
    			<th><center>No.</center></th>
    			<th><center>Nama</center></th>
    			<th><center>Jabatan</center></th>
    			<th><center>Tanda Tangan</center></th>
    		</tr>
    		<tr>
    			<td><center>1</center></td>
    			<td><?= $data['mhsw'][0]['Ketua'];?></td>
    			<td>Ketua</td>
    			<td align="left">1.</td>
    		</tr>
    		<tr>
    			<td><center>2</center></td>
    			<td><?= $data['mhsw'][0]['Penguji1'];?></td>
    			<td>Penguji 1</td>
    			<td align="center">2.</td>
    		</tr>
    		<tr>
    			<td><center>3</center></td>
    			<td><?= $data['mhsw'][0]['Penguji2'];?></td>
    			<td>Penguji 2</td>
    			<td align="left">3.</td>
    		</tr>
    	</table>
    	<p>Catatan kejadian selama seminar :
    		<br/>
    	. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  </p>
    	<p>Kelayakan melanjutkan Kegiatan Penelitian* : Ya / Tidak </p>
    	<table width="100%">
    		<tr>
    			<td width="50%"></td>
    			<td width="50%">
    				<p>Kisaran, ..... ............. ........
    					<br/>
    				Ketua Penguji,
    				<br/>
    				<br/>
    				<br/>
    				<u><?= $data['mhsw'][0]['Ketua'];?></u>
    				<br/>
    				NIDN: 
    			</p>
    			</td>
    		</tr>
    	</table>
    </div>
</section>
      <section class="sheet padding-10mm">
      	<table width="100%">
        <tr>
         <td rowspan="" width="60">
           <img src="<?= $logo ;?>" width="80" height="80"/> 
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $prodi ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>LEMBAR CATATAN PERBAIKAN SEMINAR PROPOSAL SKRIPSI</u></strong></td>
      </tr>
    </table>
   <br/>
   <br/>
   <div style="margin-left:25px ; margin-right: 25px ">
    	<table width="100%">
    		<tr>
    			<td width="15%">Nama</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['Name'] ;?></td>
    		</tr>
    		<tr>
    			<td>NIM</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['NIM'] ;?></td>
    		</tr>
    		<tr>
    			<td>Program Studi</td>
    			<td>:</td>
    			<td><?= $prodi ;?></td>
    		</tr>
    		<tr>
    			<td>Judul Skripi</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['judul'] ;?></td>
    		</tr>
    	</table>
    </div>
    	<br/>
    	<table border="1" width="100%">
    		<tr>
    			<th>No.</th>
    			<th>Uraian Catatan Perbaikan</th>
    			<th>Paraf Pembimbing</th>
    		</tr>
    		<tr>
    			<td height="250px"></td>
    			<td></td>
    			<td></td>
    		</tr>
    	</table>
<br/>
    	<table width="100%">
    		<tr>
    			<td width="50%"></td>
    			<td width="50%">
    				<p>Kisaran, ..... ............. ........
    					<br/>
    				Ketua Penguji,
    				<br/>
    				<br/>
    				<br/>
    				<u><?= $data['mhsw'][0]['Ketua'];?></u>
    				<br/>
    				NIDN: 
    			</p>
    			</td>
    		</tr>
    	</table>
    	<p style="font-size: 10pt; font-style: italic">
    		Ket : <br/>
    		Jika sudah dilakukan perbaikan, mohon dosen pembimbing memberi paraf pada masing-masing point diatas.
    	</p>
</section>




      <section class="sheet padding-10mm">
      	<table width="100%">
        <tr>
         <td rowspan="" width="60">
           <img src="<?= $logo ;?>" width="80" height="80"/> 
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $prodi ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>FORMULIR PENILAIAN SEMINAR PROPOSAL SKRIPSI</u></strong></td>
      </tr>
    </table>
    <br/>
	<div style="margin-left:25px ; margin-right: 25px ">
		<b>I. Peserta</b>
    	<table width="100%">
    		<tr>
    			<td width="15%">Nama</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['Name'] ;?></td>
    		</tr>
    		<tr>
    			<td>NIM</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['NIM'] ;?></td>
    		</tr>
    		<tr>
    			<td>Program Studi</td>
    			<td>:</td>
    			<td><?= $prodi ;?></td>
    		</tr>
    		<tr>
    			<td>Judul Skripi</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['judul'] ;?></td>
    		</tr>
    	</table>
    	<br/>
    	<b>II. Hasil Penilaian</b>
    	<table border="1" width="100%">
    		<tr>
    			<th>No.</th>
    			<th>Komponen</th>
    			<th>Bobot(B)</th>
    			<th>Nilai(N)</th>
    			<th>NilaixBobot(NB)</th>
    		</tr>
    		<tr>
    			<td>1</td>
    			<td>Struktur bahasa/logika penulisan</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>2</td>
    			<td>Kedalaman dan keluasan Teori Keilmuan yang relevan</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>3</td>
    			<td>Relevansi teori dengan masalah</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>4</td>
    			<td>Argumentasi Teoritis dalam penyusunan kerangka berpikir</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>5</td>
    			<td>Teknik pengumpulan dan keabsahan instrumen analisis data</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>6</td>
    			<td>Orisinalitas</td>
    			<td align="center">2</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>7</td>
    			<td>Penyajian materi dan penggunaan bahasa saat ujian</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>8</td>
    			<td>Hasil Penelitian</td>
    			<td align="center">2</td>
    			<td></td>
    			<td></td>
    		</tr>
    	</table>
    	<br/>
    	<b>NILAI UJIAN (NU)=NB/10=......................</b>
    	<table width="100%">
    		<tr>
    			<td width="50%">
    				<table >
    					<tr>
    						<td colspan="3"><b>Keterangan Nilai:</b></td>
    					</tr>
    					<tr>
    						<td>80-100</td>
    						<td>:</td>
    						<td><b>A</b></td>
    					</tr>
    					<tr>
    						<td>70-79</td>
    						<td>:</td>
    						<td><b>B</b></td>
    					</tr>
    				</table>
    			</td>
    			<td width="50%">
    				<p>Kisaran, ..... ............. ........
    					<br/>
    				Penguji 1,
    				<br/>
    				<br/>
    				<br/>
    				<u><?= $data['mhsw'][0]['Penguji1'];?></u>
    				<br/>
    				NIDN: 
    			</p>
    			</td>
    		</tr>
    	</table>
    </div>
</section>




      <section class="sheet padding-10mm">
      	<table width="100%">
        <tr>
         <td rowspan="" width="60">
           <img src="<?= $logo ;?>" width="80" height="80"/> 
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $prodi ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>FORMULIR PENILAIAN SEMINAR PROPOSAL SKRIPSI</u></strong></td>
      </tr>
    </table>
    <br/>
	<div style="margin-left:25px ; margin-right: 25px ">
		<b>I. Peserta</b>
    	<table width="100%">
    		<tr>
    			<td width="15%">Nama</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['Name'] ;?></td>
    		</tr>
    		<tr>
    			<td>NIM</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['NIM'] ;?></td>
    		</tr>
    		<tr>
    			<td>Program Studi</td>
    			<td>:</td>
    			<td><?= $prodi ;?></td>
    		</tr>
    		<tr>
    			<td>Judul Skripi</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['judul'] ;?></td>
    		</tr>
    	</table>
    	<br/>
    	<b>II. Hasil Penilaian</b>
    	<table border="1" width="100%">
    		<tr>
    			<th>No.</th>
    			<th>Komponen</th>
    			<th>Bobot(B)</th>
    			<th>Nilai(N)</th>
    			<th>NilaixBobot(NB)</th>
    		</tr>
    		<tr>
    			<td>1</td>
    			<td>Struktur bahasa/logika penulisan</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>2</td>
    			<td>Kedalaman dan keluasan Teori Keilmuan yang relevan</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>3</td>
    			<td>Relevansi teori dengan masalah</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>4</td>
    			<td>Argumentasi Teoritis dalam penyusunan kerangka berpikir</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>5</td>
    			<td>Teknik pengumpulan dan keabsahan instrumen analisis data</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>6</td>
    			<td>Orisinalitas</td>
    			<td align="center">2</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>7</td>
    			<td>Penyajian materi dan penggunaan bahasa saat ujian</td>
    			<td align="center">1</td>
    			<td></td>
    			<td></td>
    		</tr>
    		<tr>
    			<td>8</td>
    			<td>Hasil Penelitian</td>
    			<td align="center">2</td>
    			<td></td>
    			<td></td>
    		</tr>
    	</table>
    	<br/>
    	<b>NILAI UJIAN (NU)=NB/10=......................</b>
    	<table width="100%">
    		<tr>
    			<td width="50%">
    				<table >
    					<tr>
    						<td colspan="3"><b>Keterangan Nilai:</b></td>
    					</tr>
    					<tr>
    						<td>80-100</td>
    						<td>:</td>
    						<td><b>A</b></td>
    					</tr>
    					<tr>
    						<td>70-79</td>
    						<td>:</td>
    						<td><b>B</b></td>
    					</tr>
    				</table>
    			</td>
    			<td width="50%">
    				<p>Kisaran, ..... ............. ........
    					<br/>
    				Penguji 2,
    				<br/>
    				<br/>
    				<br/>
    				<u><?= $data['mhsw'][0]['Penguji2'];?></u>
    				<br/>
    				NIDN: 
    			</p>
    			</td>
    		</tr>
    	</table>
    </div>
</section>


<section class="sheet padding-10mm">
      	<table width="100%">
        <tr>
         <td rowspan="" width="60">
           <img src="<?= $logo ;?>" width="80" height="80"/> 
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $prodi ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>BERITA ACARA PENILAIAN SEMINAR PROPOSAL SKRIPSI</u></strong></td>
      </tr>
    </table>
    <div  style="font-size: 11pt">
    <br/>
    <p>
    	Pada hari ini ................... tanggal ...... ......................... ......... telah dilaksanakan Seminar Proposal Skripsi atas nama mahasiswa dibawah ini :
    </p>
    <table width="100%">
    	<tr>
    		<td width="65%">
    			<table width="100%">
    		<tr>
    			<td width="20%">Nama</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['Name'] ;?></td>
    		</tr>
    		<tr>
    			<td>NIM</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['NIM'] ;?></td>
    		</tr>
    		<tr>
    			<td>Program Studi</td>
    			<td>:</td>
    			<td><?= $prodi ;?></td>
    		</tr>
    		<tr>
    			<td>Judul Skripi</td>
    			<td>:</td>
    			<td><?= $data['mhsw'][0]['judul'] ;?></td>
    		</tr>
    	</table>
    		</td>
    		<td width="35%" style="vertical-align: top"> 
    			<table>
    				<tr>
    					<td>Tahun Angkatan</td>
    					<td>:</td>
    				</tr>
    				<tr>
    					<td>Tanda Tangan</td>
    					<td>:</td>
    				</tr>
    			</table>
    		</td>
    	</tr>
    </table>
    <p><b>Oleh Tim Penguji</b></p>
    <table border="1" width="100%">
    		<tr>
    			<th><center>No.</center></th>
    			<th><center>Nama</center></th>
    			<th><center>Jabatan</center></th>
    			<th><center>Tanda Tangan</center></th>
    		</tr>
    		<tr>
    			<td><center>1</center></td>
    			<td><?= $data['mhsw'][0]['Ketua'];?></td>
    			<td>Ketua</td>
    			<td align="left">1.</td>
    		</tr>
    		<tr>
    			<td><center>2</center></td>
    			<td><?= $data['mhsw'][0]['Penguji1'];?></td>
    			<td>Penguji 1</td>
    			<td align="center">2.</td>
    		</tr>
    		<tr>
    			<td><center>3</center></td>
    			<td><?= $data['mhsw'][0]['Penguji2'];?></td>
    			<td>Penguji 2</td>
    			<td align="left">3.</td>
    		</tr>
    	</table>
    	<p><b>Dengan Nilai</b></p>
    	<p>Nilai Seminar Rata-Rata (NUR) = Total Nilai Penguji/Jumlah Penguji</p>
    	<p>Nilai Seminar Rata-Rata (NUR) = ..................</p>
    	<table width="100%">
    		<tr>
    			<td width="50%">
    				<table >
    					<tr>
    						<td colspan="3"><b>Keterangan Nilai:</b></td>
    					</tr>
    					<tr>
    						<td>80-100</td>
    						<td>:</td>
    						<td><b>A</b></td>
    					</tr>
    					<tr>
    						<td>70-79</td>
    						<td>:</td>
    						<td><b>B</b></td>
    					</tr>
    				</table>
    			</td>
    			<td width="50%">
    				<p>Kisaran, ..... ............. ........
    					<br/>
    				Ketua Penguji,
    				<br/>
    				<br/>
    				<br/>
    				<u><?= $data['mhsw'][0]['Ketua'];?></u>
    				<br/>
    				NIDN: 
    			</p>
    			</td>
    		</tr>
    	</table>
    </div>