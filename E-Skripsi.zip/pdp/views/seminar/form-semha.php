<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form method="get">
      <input type="hidden" name="p" value="Seminar">
      <input type="hidden" name="x" value="PendaftaranSemha">
      <div class="row">
        <div class="col-sm-12 col-md-1 text-right">
          <label>Cari NIM</label>
        </div>
        <div class="col-sm-12 col-md-6">
          <div class="input-group input-group-md">
            <input type="text" name="nim" class="form-control" placeholder="NIM (Nomor Induk Mahasiswa)">
            <span class="input-group-append">
            <button type="submit" class="btn btn-danger btn-flat">Go!</button>
          </span>
        </div>
      </div>
    </div>
  </form>
  <br/>
  <?php 
  if(isset($_GET['nim'])){
    if($data['mhsw']){ ?>

          <form action="?p=Seminar&x=SimpanSemha" method="post">
            <input type="hidden" name="Tahun" value="<?= $data['tahun'][0]['kode'];?>">
            <input type="hidden" name="JenisSeminar" value="Hasil">
            <div class="row">
              <div class="col-sm-12 col-md-6">
                <div class="form-group">
                  <label for="NIM">NIM</label>
                  <input type="text" name="NIM" class="form-control" placeholder="NIM" value="<?= $data['mhsw'][0]['NIM'] ;?>" readonly required>
                </div>
                <div class="form-group">
                  <label for="Nama">Nama</label>
                  <input type="text" name="Nama" class="form-control" placeholder="Nama" value="<?= $data['mhsw'][0]['Name'] ;?>" readonly required>
                </div>
                <div class="form-group">
                  <label for="Prodi">Prodi</label>
                  <input type="hidden" name="Prodi" value="<?= $data['mhsw'][0]['KodeJurusan'] ;?>">
                  <input type="text" name="NamaProdi" class="form-control" placeholder="Prodi" value="<?= $data['mhsw'][0]['KodeJurusan'] == 'SI' ? 'Sistem Informasi' : 'Sistem Komputer' ;?>" readonly required>
                </div>
                <div class="form-group">
                  <label for="Judul">Judul</label>
                  <textarea name="Judul" class="form-control" rows="3" placeholder="Judul Skripsi" readonly=""><?= $data['mhsw'][0]['judul'];?></textarea> 
                </div>
                <div class="form-group">
                  <label for="Pembimbing1">Pembimbing 1</label>
                  <input type="text" name="Pembimbing1" class="form-control" placeholder="Pembimbing 1" value="<?= $data['mhsw'][0]['Dosen1'] ;?>" readonly required>
                </div>
                <div class="form-group">
                  <label for="Pembimbing2">Pembimbing 2</label>
                  <input type="text" name="Pembimbing2" class="form-control" placeholder="Pembimbing 2" value="<?= $data['mhsw'][0]['Dosen2'] ;?>" readonly required>
                </div>
              </div>
              <div class="col-sm-12 col-md-6">
                <div class="form-group">
                  <label for="Gelombang">Gelombang</label>
                  <select name="Gelombang" class="form-control input-sm" required="">
                    <option value="">-Pilih Gelombang-</option>
                    <?php 
                    $gel = array(1 => 'Gelombang 1',2 => 'Gelombang 2',3 => 'Gelombang 3',4 => 'Gelombang 4',
                            5 => 'Gelombang 5', 6 => 'Gelombang 6', 7 => 'Gelombang 7', 8 => 'Gelombang 8');
                    foreach ($gel as $key => $value) {
                      echo "<option value='".$key."'>$value </option>";
                    }
                            ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="Ketua">Ketua Penguji</label>
                  <select name="Ketua" class="form-control input-sm" >
                      <option value="">-Pilih Dosen-</option>
                      <?php
                      foreach ($data['dosen'] as $row) {
                        echo "<option value='".$row['ID']."'>$row[NamaDosen]</option>";
                      }
                      ?>
                    </select>
                </div>
                <div class="form-group">
                  <label for="Penguji1">Penguji 1</label>
                  <select name="Penguji1" class="form-control input-sm">
                      <option value="">-Pilih Dosen-</option>
                      <?php
                      foreach ($data['dosen'] as $row) {
                        echo "<option value='".$row['ID']."' >$row[NamaDosen]</option>";
                      }
                      ?>
                    </select>
                </div>
                <div class="form-group">
                  <label for="Penguji2">Penguji 2</label>
                  <select name="Penguji2" class="form-control input-sm" >
                      <option value="">-Pilih Dosen-</option>
                      <?php
                      foreach ($data['dosen'] as $row) {
                        echo "<option value='".$row['ID']."' >$row[NamaDosen]</option>";
                      }
                      ?>
                    </select>
                </div>
                <div class="form-group">
                  <label for="Tanggal">Tanggal</label>
                  <input type="text" name="Tanggal" id="tanggal" class="form-control" placeholder="Tanggal" value="">
                </div>
                <div class="form-group">
                  <label for="Jam">Jam</label>
                  <input type="text" name="Jam" class="form-control" placeholder="Jam" value="">
                </div>
                <div class="form-group">
                  <label for="Ruang">Ruang</label>
                  <input type="text" name="Ruang" class="form-control" placeholder="Ruang">
                </div>
              </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="submit" name="submit" class="btn btn-info btn-flat">Simpan</button>
              <a href="?p=Seminar&x=SeminarProposal" class="btn btn-dark btn-flat">Batal</a>
            </div>
          </form>
    <?php
  }else{ ?>
    <br/>
    <div class="row">
      <div class="col-sm-12">
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          Mahasiswa tersebut tidak dapat mendaftar seminar hasil karena tidak ada judul skrisi yang di ACC oleh Program Studi.
        </div>
      </div>
    </div>
    <?php
  }
}
?>
</div>
</div>
