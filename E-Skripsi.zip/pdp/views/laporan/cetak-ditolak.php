<center>
  <h5 style="font-family:serif;">
    YAYASAN PENDIDIKAN ROYAL TELADAN ASAHAN<br/>
SEKOLAH TINGGI MANAJEMEN INFORMATIKA DAN KOMPUTER ROYAL
  </h5>
  <p>Jln. Prof. MH. Yamin, SH No. 193 Kisaran, Telp. (0623) 41079 Fax. (0623) 41079</p>
  <hr>
  <?php
  $tahun='';
  if($data['tahun'] != 'semua'){
    $tahun = " TAHUN ". $data['tahun'];
  }
  ?>
  <h6>REKAP JUDUL MAHASISWA DITOLAK <?= $tahun ;?></h6>
</center>
<table class="table table-bordered table-sm" style="font-size: 10pt; font-family:serif;">
          <thead>
            <tr>
              <th>No.</th>
              <th>NIM</th>
              <th>Nama</th>
              <th>Judul</th>
              <th>Bahasa</th>
              <th>Objek</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no=0;

            foreach ($data['laporan'] as $key) {?>
              <tr>
                <td><?= ++$no ;?></td>
                <td><?= $key['NIM'];?></td>
                <td><?= $key['Name'];?></td>
                <td><?= $key['judul'];?></td>
                <td><?= $key['bahasa'];?></td>
                <td><?= $key['objek'];?></td>
                <td><?= $key['status'];?></td>
              </tr>              
            <?php } ?>
          </tbody>
        </table>

        <table width="100%">
          <tr>
    <td>
      <p style="float:right; width:250px; text-align:center; font-size:12px; font-family:serif;">
      Kisaran, <?php echo date("d-M-Y"); ?> <br/>dto.
      <br/><br/>

      <?php
        if($sess->get('prodi')=="SI"){
          echo "<u>William Ramdhan, M.Kom</u><br/> Ka. Prodi SI";
        }else if($sess->get('prodi')=="SK"){
          echo "<u>Muhammad Amin, M.Kom</u><br/> Ka. Prodi SK";
        }else{
          echo "<u>Rolly Yesputra, M.Kom</u><br/> Administrator";
        }
      ?>
      </p>
    </td>
    </tr>
    <tr>
    <td>
    <hr size="1">
      &COPY; <?php echo date("Y"); ?> STMIK ROYAL
    </td>
    </tr>
  </table>