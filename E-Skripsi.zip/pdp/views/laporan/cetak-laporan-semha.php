<center>
  <h5 style="font-family:serif;"><b>
    YAYASAN PENDIDIKAN ROYAL TELADAN ASAHAN<br/>
SEKOLAH TINGGI MANAJEMEN INFORMATIKA DAN KOMPUTER ROYAL</b>
  </h5>
  <p>Jln. Prof. MH. Yamin, SH No. 193 Kisaran, Telp. (0623) 41079 Fax. (0623) 41079</p>
  <hr>
  <?php
  $tahun='';
  if($data['tahun'] != 'semua'){
    $tahun = " TAHUN ". $data['tahun'];
  }
  $prodi ='';
  if($data['prodi'] != 'semua'){
    $prodi = $data['prodi'] == 'SI' ? ' PROGRAM STUDI SISTEM INFORMASI' : ' PROGRAM STUDI SISTEM KOMPUTER';
  }
  ?>
  <h6><b>REKAP DATA SEMINAR HASIL <?= $tahun ;?>  <?= $prodi;?></b></h6>
</center>
<br/>
<table class="table table-bordered table-sm">
            <thead>
              <tr>
                <th><center>No.</center></th>
                <th><center>NIM</center></th>
                <th><center>Nama</center></th>
                <th><center>Gel.</center></th>
                <th><center>Ketua</center></th>
                <th><center>Penguji1</center></th>
                <th><center>Penguji2</center></th>
                <th><center>Tanggal</center></th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no=0;
              foreach ($data['laporan'] as $value) {?>
                <tr>
                  <td><?= ++$no;?></td>
                  <td><?= $value['NIM'];?></td>
                  <td><?= $value['Name'];?></td>
                  <td>Gel. <?= $value['Gelombang'];?></td>
                  <td><?= $value['Ketua'];?></td>
                  <td><?= $value['Penguji1'];?></td>
                  <td><?= $value['Penguji2'];?></td>
                  <td><?= $value['Tanggal'];?></td>
                </tr>
                <?php
              }
              ?>
            </tbody>
          </table>