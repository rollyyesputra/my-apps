          <center>
  <h5 style="font-family:serif;"><b>
    YAYASAN PENDIDIKAN ROYAL TELADAN ASAHAN<br/>
SEKOLAH TINGGI MANAJEMEN INFORMATIKA DAN KOMPUTER ROYAL</b>
  </h5>
  <p>Jln. Prof. MH. Yamin, SH No. 193 Kisaran, Telp. (0623) 41079 Fax. (0623) 41079</p>
  <hr>
  <?php
  $tahun='';
  if($data['tahun'] != 'semua'){
    $tahun = " TAHUN ". $data['tahun'];
  }
  $prodi ='';
  if($data['prodi'] != 'semua'){
    $prodi = $data['prodi'] == 'SI' ? ' PROGRAM STUDI SISTEM INFORMASI' : ' PROGRAM STUDI SISTEM KOMPUTER';
  }
  ?>
  <h6><b>REKAP DATA PEMBAYARAN BIMBINGAN SKRIPSI <?= $tahun ;?>  <?= $prodi;?></b></h6>
</center>
<br/>
          <table class="table table-bordered table-sm">
            <thead>
              <tr>
                <th>No.</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Prodi</th>
                <th>Tgl Bayar</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no=0;
              foreach ($data['all'] as $value) {?>
                <tr>
                  <td><?= ++$no;?></td>
                  <td><?= $value['NIM'];?></td>
                  <td><?= $value['Name'];?></td>
                  <td><?= $value['KodeJurusan'] == 'SI' ? 'SISTEM INFORMASI' : 'SISTEM KOMPUTER';?></td>
                  <td><?= $value['tgl_bayar'];?></td>
                  <td><?= $value['STATUS_BYR'];?></td>
                </tr>
                <?php
              }
              ?>
            </tbody>
          </table>