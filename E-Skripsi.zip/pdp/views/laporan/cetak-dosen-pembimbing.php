<center>
  <h5 style="font-family:serif;">
    YAYASAN PENDIDIKAN ROYAL TELADAN ASAHAN<br/>
SEKOLAH TINGGI MANAJEMEN INFORMATIKA DAN KOMPUTER ROYAL
  </h5>
  <p>Jln. Prof. MH. Yamin, SH No. 193 Kisaran, Telp. (0623) 41079 Fax. (0623) 41079</p>
  <hr>
  <?php
  $tahun='';
  if($data['tahun'] != 'semua'){
    $tahun = " TAHUN ". $data['tahun'];
  }
  ?>
  <h6>LAPORAN DOSEN PEMBIMBING SKRIPSI <?= $tahun ;?></h6>
</center>
<br/>
<table class="table table-bordered table-striped table-sm" style="font-size: 10pt">
    <thead>
      <tr>
        <th>No.</th>
        <th>NIM</th>
        <th>Nama</th>
        <th>Prodi</th>
        <th>Dosen 1</th>
        <th>Dosen 2</th>
        <th>No. Surat</th>
        <th>Bimbingan s/d</th>
        <th>Tahun</th>
    </tr>
</thead>
<tbody>
  <?php 
  $no =0;
  foreach ($data['pembimbing'] as $key) {?>
    <tr>
      <td><?= ++$no ;?></td>
      <td><?= $key['NIM']; ?></td>
      <td><?= $key['Name'];?></td>
      <td><?= $key['KodeJurusan'];?></td>
      <td><?= $key['Dosen1'];?></td>
      <td><?= $key['Dosen2'];?></td>
      <td><?= $key['NoSurat'];?></td>
      <td><?= $key['Mbimbingan']."/".$key['Sbimbingan'];?></td>
      <td><?= $key['Tahun'];?></td>
</tr>
<?php }?>
</tbody>
</table>
<table width="100%">
          <tr>
    <td>
      <p style="float:right; width:250px; text-align:center; font-size:12px; font-family:serif;">
      Kisaran, <?php echo date("d-M-Y"); ?> <br/>dto.
      <br/><br/>

      <?php
        if($sess->get('prodi')=="SI"){
          echo "<u>William Ramdhan, M.Kom</u><br/> Ka. Prodi SI";
        }else if($sess->get('prodi')=="SK"){
          echo "<u>Muhammad Amin, M.Kom</u><br/> Ka. Prodi SK";
        }
      ?>
      </p>
    </td>
    </tr>
    <tr>
    <td>
    <hr size="1">
      &COPY; <?php echo date("Y"); ?> STMIK ROYAL
    </td>
    </tr>
  </table>