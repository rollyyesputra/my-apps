  <?php 
  $tahun = filter_input(INPUT_GET, 'tahun');
  $prodi = filter_input(INPUT_GET, 'prodi');
  ?>
  <div class="card">
    <div class="card-header">
      <h5 class="card-title"><?= $data['sub_title'];?></h5>

      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-widget="collapse">
          <i class="fa fa-minus"></i>
        </button>
        <button type="button" class="btn btn-tool" data-widget="remove">
          <i class="fa fa-times"></i>
        </button>
      </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <form class="" method="get" action="">
        <input type="hidden" name="p" value="Laporan">
        <input type="hidden" name="x" value="LaporanSempro">
        <div class="form-group">
          <div class="row">
            <label class="col-sm-12 col-md-2 text-right">Tahun</label>
            <div class="col-sm-12 col-md-4">
              <select name="tahun" required="">
                <option value="semua">Semua</option>
                <?php
                foreach ($data['ta'] as $row) {
                  $tahun == $row['kode'] ? $s='selected' : $s='';
                  echo "<option value='".$row['kode']."' $s>$row[kode]</option>";
                }
                ?>
              </select>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="row">
            <label class="col-sm-12 col-md-2 text-right">Program Studi</label>
            <div class="col-sm-12 col-md-4">
              <select name="prodi">
                <option value="semua">Semua</option>
                <?php 
                $optionprodi = array('SI' => 'Sistem Informasi', 'SK'=>'Sistem Komputer');
                foreach ($optionprodi as $value =>$key) {
                  $prodi == $value ? $s='selected' : $s='';
                  echo "<option value='".$value."' $s>$key</option>";
                }
                ?>
              </select>
            </div>
          </div>
        </div>
         <div class="form-group">
          <div class="row">
            <label class="col-sm-12 col-md-2 text-right">Gelombang</label>
            <div class="col-sm-12 col-md-4">
              <select name="gel" class="form-control input-sm">
                    <option value="">-Pilih Gelombang-</option>
                    <?php 
                    $gel = array(1 => 'Gelombang 1',2 => 'Gelombang 2',3 => 'Gelombang 3',4 => 'Gelombang 4',
                            5 => 'Gelombang 5', 6 => 'Gelombang 6', 7 => 'Gelombang 7', 8 => 'Gelombang 8');
                    foreach ($gel as $key => $value) {
                      $key == $data['mhsw'][0]['Gelombang'] ? $sg ='selected' : $sg='';
                      echo "<option value='".$key."' $sg>$value </option>";
                    }
                            ?>
                  </select>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="row">
            <div class="col-sm-12 offset-md-2">
              <input type="submit" name="go" value="Refresh" class="btn btn-danger btn-sm btn-flat">
            </div>
          </div>
        </div>
      </form>
      <br/>
      <?php 
      if(isset($_GET['go'])){
        if(!empty($data['laporan'])){ ?>
          <a href="" onclick="cetak_slip('?p=Laporan&x=CetakSempro&tahun=<?= filter_input(INPUT_GET, 'tahun'); ?>&prodi=<?= filter_input(INPUT_GET, 'prodi'); ?>&gel=<?= filter_input(INPUT_GET, 'gel'); ?>','Cetak Laporan Seminar Proposal','width=800,height=600,scrollbars=yes')" class="btn btn-danger" data-toggle="tooltip" title="Cetak Laporan Seminar Proposal"><i class="fa fa-print"></i> Cetak Laporan </a>
        <br/>
        <br/>
          <table class="table table-bordered table-sm">
            <thead>
              <tr>
                <th>No.</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Gel.</th>
                <th>Ketua</th>
                <th>Penguji1</th>
                <th>Penguji2</th>
                <th>Tanggal</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no=0;
              foreach ($data['laporan'] as $value) {?>
                <tr>
                  <td><?= ++$no;?></td>
                  <td><?= $value['NIM'];?></td>
                  <td><?= $value['Name'];?></td>
                  <td>Gel. <?= $value['Gelombang'];?></td>
                  <td><?= $value['Ketua'];?></td>
                  <td><?= $value['Penguji1'];?></td>
                  <td><?= $value['Penguji2'];?></td>
                  <td><?= $value['Tanggal'];?></td>
                </tr>
                <?php
              }
              ?>
            </tbody>
          </table>
          <?php 
        }else{  ?>
          <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            Data tidak ditemukan.
          </div>
          <?php }
        }
        ?>
      </div>
    </div>