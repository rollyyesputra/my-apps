     <?php 
     $tahun = filter_input(INPUT_GET, 'tahun');
     $prodi = filter_input(INPUT_GET, 'prodi');
     ?>
     <div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-widget="remove">
              <i class="fa fa-times"></i>
          </button>
      </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <?php
    if(!empty($data['pesan'])){?>
       <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <?= $data['pesan'] ;?>
      </div>
      <?php
  }
  ?>
  <form class="" method="get" action="">
    <input type="hidden" name="p" value="Laporan">
    <input type="hidden" name="x" value="DosenPembimbing">
    <div class="form-group">
        <div class="row">
           <label class="col-sm-12 col-md-2 text-right">Tahun</label>
           <div class="col-sm-12 col-md-4">
              <select name="tahun" required="">
                 <option value="semua">Semua</option>
                 <?php
                 foreach ($data['ta'] as $row) {
                    $tahun == $row['kode'] ? $s='selected' : $s='';
                    echo "<option value='".$row['kode']."' $s>$row[kode]</option>";
                }
                ?>
            </select>
        </div>
    </div>
</div>
<?php 
if($sess->get('prodi') == 'all'){?>
    <div class="form-group">
       <div class="row">
           <label class="col-sm-12 col-md-2 text-right">Program Studi</label>
           <div class="col-sm-12 col-md-4">
              <select name="prodi">
                 <option value="semua">Semua</option>
                 <?php 
                 $optionprodi = array('SI' => 'Sistem Informasi', 'SK'=>'Sistem Komputer');
                 foreach ($optionprodi as $value =>$key) {
                    $prodi == $value ? $s='selected' : $s='';
                    echo "<option value='".$value."' $s>$key</option>";
                }
                ?>
            </select>
        </div>
    </div>
</div>
<?php } ?>
<div class="form-group">
    <div class="row">
       <div class="col-sm-12 offset-md-2">
          <input type="submit" name="go" value="Refresh" class="btn btn-danger btn-sm btn-flat">
      </div>
  </div>
</div>
</form>
<br/>
<?php 
if(isset($_GET['go'])){?>
  <a href="" onclick="cetak_slip('?p=Laporan&x=CetakDosenPembimbing&tahun=<?= filter_input(INPUT_GET, 'tahun'); ?>','Cetak Judul Mahasiswa Diterima','width=800,height=600,scrollbars=yes')" class="btn btn-danger" data-toggle="tooltip" title="Cetak Laporan Judul"><i class="fa fa-print"></i> Cetak Laporan </a>
  <br/>
  <br/>
<table class="table table-bordered table-striped table-sm" style="font-size: 10pt">
    <thead>
      <tr>
        <th>No.</th>
        <th>NIM</th>
        <th>Nama</th>
        <th>Prodi</th>
        <th>Dosen 1</th>
        <th>Dosen 2</th>
        <th>No. Surat</th>
        <th>Bimbingan s/d</th>
        <th>Tahun</th>
    </tr>
</thead>
<tbody>
  <?php 
  $no =0;
  foreach ($data['pembimbing'] as $key) {?>
    <tr>
      <td><?= ++$no ;?></td>
      <td><?= $key['NIM']; ?></td>
      <td><?= $key['Name'];?></td>
      <td><?= $key['KodeJurusan'];?></td>
      <td><?= $key['Dosen1'];?></td>
      <td><?= $key['Dosen2'];?></td>
      <td><?= $key['NoSurat'];?></td>
      <td><?= $key['Mbimbingan']."/".$key['Sbimbingan'];?></td>
      <td><?= $key['Tahun'];?></td>
</tr>
<?php }?>
</tbody>
</table>
<?php }?>
</div>
</div>
