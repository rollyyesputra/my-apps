<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="card-title"> <i class="fa fa-eye" aria-hidden></i> Detail Mahasiswa</h5>

      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-2">
            <strong>NIM</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['NIM']?>
          </div>

          <div class="col-md-2">
            <strong>Nama Lengkap</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['Name']?>
          </div>

          <div class="col-md-2">
            <strong>Jenis Kelamin</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['Sex'] == 'L' ? 'Laki-laki' :'Perempuan'; ?>
          </div>

          <div class="col-md-2">
            <strong>Tgl Lahir</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['TglLahir']?>
          </div>

          <div class="col-md-2">
            <strong>Tempat Lahir</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['TempatLahir']?>
          </div>

          <div class="col-md-2">
            <strong>Jurusan</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['Prodi']?>
          </div>

          <div class="col-md-2">
            <strong>No. Telp.</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['Phone']?>
          </div>

          <div class="col-md-2">
            <strong>Email</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['Email']?>
          </div>

          <div class="col-md-2">
            <strong>Alamat</strong>
          </div>
          <div class="col-md-10">
            : <?=$data['row'][0]['Alamat1']?>
          </div>

        </div>
      </div>

      <div class="card-footer">
        <a href="?p=Mahasiswa" class="btn btn-danger btn-sm"> <i class="fa fa-history" aria-hidden></i>  Kembali</a>
        <a href="?p=Mahasiswa&x=Ubah&id=<?=$data['row'][0]['ID']?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> Update </a>
        <a href="?p=Mahasiswa&x=Hapus&id=<?=$data['row'][0]['ID']?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Yakin ingin menghapus mahasiswa ini?')"> <i class="fa fa-remove" aria-hidden></i> Hapus</a>
      </div>

    </div>
  </div>
</div>
