<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <form method="get">
      <input type="hidden" name="p" value="Mahasiswa">
      <input type="hidden" name="x" value="aktifkanmhsw">
      <div class="row">
        <div class="col-sm-12 col-md-2 text-right">
          <label>Filter Kelas</label>
        </div>
        <div class="col-sm-12 col-md-9">
          <div class="input-group input-group-md">
            <input type="text" name="cari" class="form-control" placeholder="Nama kelas. exp: SI8A">
            <span class="input-group-append">
              <button type="submit" name="go" value="filter" class="btn btn-danger btn-flat">Filter Kelas</button>
              <button type="submit" name="go" value="semua" class="btn btn-info btn-flat">Semua</button>
            </span>
          </div>
        </div>
      </div>
    </form>
    <br/>
    <?php 
    if(isset($_GET['go'])){
      if($data['mhsw']){ ?>
        <form action="?p=Mahasiswa&x=aktifkan" method="post" enctype="multipart/form-data">
          <input type="hidden" name="ta" value="<?= $data['ta'][0]['kode'];?>">
          <table class="table table-bordered table-striped table-hover table-sm" id="dtskripsi">
            <thead>
              <tr>
                <th>No.</th>
                <th>Pilih</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Kelas</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no=0;
              foreach ($data['mhsw'] as $key) { ?>
                <tr>
                  <td><?= ++$no ;?></td>
                  <td><input type="checkbox" name="pilih[]" value="<?= $key['NIM'];?>"></td>
                  <td><?= $key['NIM']; ?></td>
                  <td><?= $key['Name'];?></td>
                  <td><?= $key['TglLahir'];?></td>
                  <td><?= $key['KodeProgram'];?></td>
                </tr>
                <?php 
              }?>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="6">
                  <input type="submit" name="aktifkan" class="btn btn-danger btn-flat" value="Aktifkan Akun Mahasiswa">
                </td>
              </tr>
            </tfoot>
          </table>
        </form>
        <?php }else{ ?>
          <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            Data tidak ditemukan
          </div>
          <?php
        }
      }
      ?>
    </div>
  </div>