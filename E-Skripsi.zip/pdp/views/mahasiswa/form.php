<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="card-title"><?= $data['sub_title'];?></h5>
      </div>
      <div class="card-body">
        <form method="post" action="<?= $data['action'] ;?>">
          <input type="hidden" name="ID" value="<?=$data['input']['ID']?>">
          <fieldset class="form-group">
            <label for="txtNim">NIM</label>
            <input type="text" name="NIM" id="nim" value="<?=$data['input']['NIM']?>" class="form-control" placeholder="Masukkan Nim" maxlength="10" required>
            <small class="text-muted">Nomor induk mahasiswa</small>
            <?php 
          if(!empty($data['pesan'])){ ?>
            <div class="alert alert-danger"><?php echo $data['pesan']."</div>"; } ?>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtNamaLengkap">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="Name" value="<?=$data['input']['Name']?>" placeholder="Nama lengkap" required>
            <small class="text-muted">Nama lengkap mahasiswa</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtNamaLengkap">Tanggal Lahir</label>
            <input type="text" class="form-control" name="TglLahir" value="<?=$data['input']['TglLahir']?>" placeholder="YYYY/MM/DD" required>
            <small class="text-muted">Tanggal Lahir</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtNamaLengkap">Tempat Lahir</label>
            <input type="text" class="form-control" id="TempatLahir" name="TempatLahir" value="<?=$data['input']['TempatLahir']?>" placeholder="Nama lengkap" required>
            <small class="text-muted">Tempat Lahir</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtNamaLengkap">Jenis Kelamin</label>
            <select name="Sex" class="form-control" required="">
              <option value="">-Pilih-</option>
              <option value="L" <?=$data['input']['Sex'] == 'L' ? 'selected' : '' ; ?> >Laki-Laki</option>
              <option value="P" <?=$data['input']['Sex'] == 'P' ? 'selected' : '' ; ?> >Perempuan</option>
            </select>
            <small class="text-muted">Jenis Kelamin</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="">Program Studi</label>
            <select name="KodeJurusan"  class="form-control" required="">
              <option value="">-Pilih-</option>
              <?php 
              foreach ($data['prodi'] as $value) {
                $value['Kode'] == $data['input']['KodeJurusan'] ? $s='selected' : $s='';
                echo "<option value='".$value['Kode']."' $s >".$value['Prodi']."</option>";
              }
              ?>
            </select>
            <small class="text-muted">Program Studi</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="">No. Telp</label>
            <input type="text" class="form-control" id="Phone" name="Phone" value="<?=$data['input']['Phone']?>" placeholder="Nomor Telepon" required>
            <small class="text-muted">Nomor Telepon</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtEmail">Email</label>
            <input type="email" class="form-control" id="email" name="Email" value="<?=$data['input']['Email']?>" placeholder="Email Aktif" required>
            <small class="text-muted">Email valid mahasiswa</small>
          </fieldset>
          <fieldset class="form-group">
            <label for="txtNamaLengkap">Alamat</label>
            <textarea name="Alamat1" id="Alamat1" class="form-control" rows="8" cols="80" required><?=$data['input']['Alamat1']?></textarea>
            <small class="text-muted">Alamat lengkap mahasiswa</small>
          </fieldset>
          <button type="submit" name="simpan" class="btn btn-success"> <i class="fa fa-edit" aria-hidden></i> Update</button>
          <a href="?p=Mahasiswa" class="btn btn-danger"> <i class="fa fa-history" aria-hidden></i> Kembali</a>
        </form>
      </div>
    </div>
  </div>
</div>
