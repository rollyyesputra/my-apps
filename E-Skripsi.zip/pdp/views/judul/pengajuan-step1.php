<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <?php 
    if(!empty($data['pesan'])){ ?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <?= $data['pesan'] ;?><br/>
      </div>
      <?php } ;
      if(!empty($data['pesan_judul'])){ ?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <?= $data['pesan_judul'] ;?><br/>
      </div>
      <?php } ;

      if($data['pengajuan']){?>
        <form action="?p=Judul&x=PengajuanJudul" class="form-horizontal" method="post">
         <div class="form-group">
          <label class="col-sm-3 control-label">Judul Skripsi</label>
          <div class="col-sm-10">
            <textarea name="Judul" class="form-control" rows="3" placeholder="Judul skripsi min. 6 kata dan max 16 kata !!!"><?php echo $data['input']['Judul'] ;?></textarea>
          </div>
          <?php 
          if(!empty($data['error_judul'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data['error_judul'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label">Objek Penilaian</label>
            <div class="col-sm-10">
              <input type="text" name="Objek" class="form-control" value="<?php echo $data['input']['Objek'] ;?>" placeholder="Objek Penelitian">
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-3 control-label">Instansi Penelitian</label>
            <div class="col-sm-10">
              <input type="text" name="Instansi" class="form-control" value="<?php echo $data['input']['Instansi'] ;?>" placeholder="Instansi Penelitian">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label">Bahasa Pemrograman</label>
            <div class="col-sm-10">
              <select name="Bahasa" class="form-control" required="">
                <option value="">-Pilih Bahasa-</option>
                <?php 
                foreach ($data['bahasa'] as $value) {
                  $value['nama'] == $data['input']['Bahasa'] ? $s ='selected' : $s=''; ?>
                  <option value="<?= $value['nama'];?>" <?= $s ;?>><?= $value['nama'];?></option>
                  <?php  
                }?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <input type="submit" name="cek" class="btn btn-info btn-flat" value="Cek Ketersediaan Judul">
            <input type="reset" name="" class="btn btn-danger btn-flat" value="Reset">
            <a href="?p=Judul&x=JudulProdi&prodi=sk" class="btn btn-dark btn-flat">Batal</a>
          </div>
        </form>
        <?php } ?>
      </div>
    </div>