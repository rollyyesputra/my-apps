<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <?php 
    if(!empty($data['pesan'])){ ?>
<div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data['pesan'] ;?><br/>
            </div>
    <?php } ?>
                <form action="?p=Judul&x=PengajuanJudulStep2" class="form-horizontal" method="post">
                 <div class="form-group">
                    <label class="col-sm-3 control-label">NIM</label>
                    <div class="col-sm-10">
                      <input type="text" name="NIM" class="form-control" value="<?= $data['input']['NIM'] ;?>" readonly placeholder="NIM">
                    </div>
                     <?php 
          if(!empty($data2['NIM'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['NIM'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                   <div class="form-group">
                    <label class="col-sm-3 control-label">Program Studi</label>
                    <div class="col-sm-10">
                      <input type="hidden" name="Prodi" value="<?= $data['input']['Prodi'];?>">
                      <input type="text" name="NamaProdi" class="form-control" value="<?= $data['input']['Prodi'] == 'SK' ? 'Sistem Komputer' : 'Sistem Informasi' ;?>" readonly placeholder="NIM">
                    </div>
                     <?php 
          if(!empty($data2['Prodi'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Prodi'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                   <div class="form-group">
                    <label class="col-sm-3 control-label">Judul Skripsi</label>
                    <div class="col-sm-10">
                      <textarea name="Judul" class="form-control" rows="3" placeholder="Judul Skripsi" readonly=""><?= $data['input']['Judul']; ?></textarea>
                    </div>
                     <?php 
          if(!empty($data2['Judul'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Judul'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                   <div class="form-group">
                    <label class="col-sm-3 control-label">Objek Penilaian</label>
                    <div class="col-sm-10">
                      <input type="text" name="Objek" class="form-control" value="<?= $data['input']['Objek'] ;?>" placeholder="Objek Penelitian" readonly="">
                    </div>
                     <?php 
          if(!empty($data2['Objek'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Objek'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Bahasa Pemrograman</label>
                    <div class="col-sm-10">
                       <input type="text" name="Bahasa" class="form-control" value="<?= $data['input']['Bahasa'] ;?>" placeholder="Bahasa Pemrograman" readonly="">
                    </div>
                     <?php 
          if(!empty($data2['Bahasa'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Bahasa'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Instansi Penelitian</label>
                    <div class="col-sm-10">
                      <input type="text" name="Instansi" class="form-control" value="<?= $data['input']['Instansi'] ;?>" placeholder="Instansi Penelitian" readonly="">
                    </div>
                     <?php 
          if(!empty($data2['Instansi'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Instansi'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Latar Belakang</label>
                    <div class="col-sm-10">
                     <textarea id="editor1" name="Latar" class="form-control" rows="10" style="width: 100%"><?= $data['input']['Latar'] ;?></textarea>
                    </div>
                     <?php 
          if(!empty($data2['Latar'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Latar'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Rumusan Masalah</label>
                    <div class="col-sm-10">
                      <textarea id="editor2" name="Rumusan" class="form-control" rows="10" style="width: 100%"><?= $data['input']['Rumusan'] ;?></textarea>
                    </div>
                     <?php 
          if(!empty($data2['Rumusan'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Rumusan'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Batasan Masalah</label>
                    <div class="col-sm-10">
                      <textarea id="editor3" name="Batasan" class="form-control" rows="10" style="width: 100%"><?= $data['input']['Batasan'] ;?></textarea>
                    </div>
                     <?php 
          if(!empty($data2['Batasan'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Batasan'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Tujuan Penelitian</label>
                    <div class="col-sm-10">
                     <textarea id="editor4" name="Tujuan" class="form-control" rows="10" style="width: 100%"><?= $data['input']['Tujuan'] ;?></textarea>
                    </div>
                     <?php 
          if(!empty($data2['Tujuan'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Tujuan'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Manfaat Penelitian</label>
                    <div class="col-sm-10">
                     <textarea id="editor5" name="Manfaat" class="form-control" rows="10" style="width: 100%"><?= $data['input']['Manfaat'] ;?></textarea>
                    </div>
                     <?php 
                     if(!empty($data2['Manfaat'])){ ?>
          <div class="col-sm-10">            
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data2['Manfaat'] ;?><br/>
            </div>
          </div>
            <?php   } ?>
                  </div>
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-info btn-flat" value="Simpan">
                    <a href="?p=Judul&x=PengajuanJudul" class="btn btn-dark btn-flat">Batal</a>
                  </div>
                </form>
  </div>
</div>