<div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-widget="remove">
              <i class="fa fa-times"></i>
          </button>
      </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table id="dtskripsi" class="table table-bordered table-sm table-hover table-striped" border="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Prodi</th>
                            <th>Judul</th>
                            <th>Bahasa</th>
                            <th>Status</th>
                            <th>Tgl Pengajuan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($data['judul'] as $key) {
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                   <a href="" onclick="cetak_slip('?p=Judul&x=Detail&id=<?= $key['id'] ?>','Judul Mahasiswa','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm" data-toggle="tooltip" title="Proses Judul"> <?= $key['nim'] ?> </a>
                                    </td>
                                <td><?= $key['prodi'] ?></td>
                                <td><?= $key['judul'] ?></td>
                                <td><?= $key['bahasa'] ?></td>
                                <td class="text-bold"><?= $key['status'] ?></td>
                                <td><?= $key['tgl_pengajuan'] ?>
                                </td>
                            </tr>
                            <?php $no++;
                        } ?>
                    </tbody>
                </table>
  </div>
</div>