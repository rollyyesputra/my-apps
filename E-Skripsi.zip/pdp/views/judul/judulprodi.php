<?php 
$prd = filter_input(INPUT_GET, 'prodi')== '' ? '' : filter_input(INPUT_GET, 'prodi');
$tahun = filter_input(INPUT_GET, 'thn') == '' ? '' : filter_input(INPUT_GET, 'thn');
$key = filter_input(INPUT_GET, 'key') == '' ? '' : filter_input(INPUT_GET, 'key');
$sts = filter_input(INPUT_GET, 'sts') == '' ? '' : filter_input(INPUT_GET, 'sts');

$link = '&x=JudulProdi';
if(!empty($tahun)){
    $link .= "&thn=$tahun";
}
if(!empty($key)){
    $link .= "&key=$key";
}
if(!empty($sts)){
    $link .= "&sts=$sts";
}
if(!empty($prd)){
    $link .= "&prodi=$prd";
}
?>
<div class="row">
    <div class="col-md-12 col-xs-12">
        <h2>
            <?php 
            if($sess->get('level') == 5){ ?>
                <a href="?p=Judul&x=PengajuanJudul" class="btn btn-info" data-toggle="tooltip" title="Tambah Judul Baru"> <i class="fa fa-plus"></i> Tambah Judul Baru</a>
                <?php }
                if($sess->get('level') == 2){?>
                    <a href="?p=Judul&x=JudulOffline" class="btn btn-info" data-toggle="tooltip" title="Tambah Judul Offline"> <i class="fa fa-plus"></i> Tambah Judul Offline</a>
                    <?php } 
                    if($sess->get('level') == 2 or $sess->get('level') == 5 ){?>

                        <a href="?p=Judul&x=JudulProdi&prodi=<?= $prd ;?>" class="btn btn-info" data-toggle="tooltip" title="Judul Sudah Diterima"> <i class="fa fa-eye"></i> Semua</a>
                        <a href="?p=Judul&x=JudulProdi&prodi=<?= $prd ;?>&thn=<?= $tahun ;?>&sts=proses" class="btn btn-info" data-toggle="tooltip" title="Judul Sudah Diterima"> <i class="fa fa-eye"></i> Diproses</a>
                        <a href="?p=Judul&x=JudulProdi&prodi=<?= $prd ;?>&thn=<?= $tahun ;?>&sts=terima" class="btn btn-info" data-toggle="tooltip" title="Judul Sudah Diterima"> <i class="fa fa-eye"></i> Diterima</a>
                        <a href="?p=Judul&x=JudulProdi&prodi=<?= $prd ;?>&thn=<?= $tahun ;?>&sts=tolak" class="btn btn-info" data-toggle="tooltip" title="Judul Sudah Ditolak"> <i class="fa fa-eye"></i> Ditolak</a>
                        <?php } ?>
                    </h2>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?= $data['sub_title'];?></h3>                        
                        </div>
                        <div class="card-body">
                            <form method="get">
                                <input type="hidden" name="p" value="Judul">
                                <input type="hidden" name="x" value="JudulProdi">
                                <input type="hidden" name="prodi" value="<?= $prd ;?>">
                                <input type="hidden" name="sts" value="<?= $sts ;?>">
                                <div class="form-row">
                                    <div class="col-7">
                                        <input type="text" name="key" value="<?= $key ;?>" class="form-control" placeholder="Cari NIM atau Judul Skripsi">
                                    </div>
                                    <div class="col">
                                      <select class="form-control" id="thn" name="thn">
                                          <option value="">Tahun Akademik</option>
                                          <?php
                                          foreach ($data['ta'] as $row) {
                                              $tahun == $row['kode'] ? $s='selected' : $s='';
                                              echo "<option value='".$row['kode']."' $s>$row[kode]</option>";
                                          }
                                          ?>
                                      </select>
                                  </div>
                                  <div class="col">
                                    <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> <b>Cari</b></button>
                                    <a href="?p=Judul<?= $link ;?>" class="btn btn-danger"><i class="fa fa-refresh"></i> <b>Semua</b></a>
                                </div>
                            </div>
                        </form>
                        <br/>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm table-hover table-striped" border="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIM</th>
                                        <th>Prodi</th>
                                        <th>Judul</th>
                                        <th>Bahasa</th>
                                        <th>Validasi</th>
                                        <th>Status</th>
                                        <?php if($sess->get('level') == 1){?><th>Actions</th><?php } ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    for ($i = 0; $i < count($data['judul']); $i++) {
                                        ?>
                                        <tr>
                                            <td><?= $no ?></td>
                                            <td>
                                                <?php if($data['judul'][$i]['status'] == 'SEDANG DIPROSES' and $sess->get('prodi') != 'all' and $sess->get('level') == 2){ ?>

                                                    <a href="" onclick="cetak_slip('?p=Judul&x=DetailProses&id=<?= $data['judul'][$i]['id'] ?>','Judul Mahasiswa','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm" data-toggle="tooltip" title="Proses Judul"> <?= $data['judul'][$i]['NIM'] ?> </a>
                                                    <?php }else{ ?>
                                                        <a href="" onclick="cetak_slip('?p=Judul&x=Detail&id=<?= $data['judul'][$i]['id'] ?>','Judul Mahasiswa','width=800,height=600,scrollbars=yes')" class="btn btn-info btn-sm" data-toggle="tooltip" title="Lihat Selengkapnya"> <?= $data['judul'][$i]['NIM'] ?> </a>
                                                        <?php }?>
                                                    </td>
                                                    <td><?= $data['judul'][$i]['prodi'] ?></td>
                                                    <td><?= $data['judul'][$i]['judul'] ?></td>
                                                    <td><?= $data['judul'][$i]['bahasa'] ?></td>
                                                    <td align="center"><?= $data['judul'][$i]['rekomendasi'];?></td>
                                                    <td class="text-bold">
                                                        <?php
                                                        if($data['judul'][$i]['status'] == 'SEDANG DIPROSES'){
                                                           if($data['judul'][$i]['rekomendasi'] == ''){
                                                            echo "Sedang Diproses";
                                                        }elseif($data['judul'][$i]['rekomendasi'] == 'BELUM'){
                                                            echo 'Proses Seleksi';
                                                        }else{?>
                                                            <a href="?p=Judul&x=ProsesJudul&nim=<?= $data['judul'][$i]['NIM'];?>&sts=1&idj=<?= $data['judul'][$i]['id'];?>" class="btn btn-info btn-sm btn-flat" onclick="return confirm('Apakah Anda Yakin Ingin Menerima Judul Ini?')">ACC</a>
                                                            <a href="?p=Judul&x=ProsesJudul&nim=<?= $data['judul'][$i]['NIM'];?>&sts=2&idj=<?= $data['judul'][$i]['id'];?>" class="btn btn-danger btn-sm btn-flat" onclick="return confirm('Apakah Anda Yakin Ingin Menolak Judul Ini?')">Tolak</a>
                                                            <?php }
                                                        }else{
                                                            echo $data['judul'][$i]['status'];
                                                        } ?>
                                                    </td>
                                                    <?php if($sess->get('level') == 1){?> <td>
                                                        <a href="?p=Judul&x=Ubah&id=<?= $data['judul'][$i]['id'] ?>" class="btn btn-outline-success btn-sm" data-toggle="tooltip" title="Edit Data"> <i class="fa fa-edit" aria-hidden></i> </a>
                                                        <a href="?p=Judul&x=Hapus&id=<?= $data['judul'][$i]['id'] ?>" class="btn btn-outline-danger btn-sm" data-toggle="tooltip" title="Hapus data"> <i class="fa fa-remove" aria-hidden></i> </a>
                                                        </td><?php } ?>
                                                    </tr>
                                                    <?php $no++;
                                                } ?>
                                            </tbody>
                                            <tr>
                                                <td colspan="8" align="left">Jumlah : <?= $data['jumlah'];?></td>
                                            </tr>
                                        </table>
                                        <ul class="pagination">       
                                            <!-- LINK FIRST AND PREV -->        
                                            <?php if($data['page'] == 1){
         // Jika page adalah page ke 1, maka disable link PREV        
                                              ?>          
                                              <li class="page-item disabled"><a href="#" class="page-link">First</a> </li>          
                                              <li class="page-item disabled"><a href="#" class="page-link">&laquo;</a> </li>        
                                              <?php }else{ 
          // Jika page bukan page ke 1          
                                                  $link_prev = ($data['page'] > 1)? $data['page'] - 1 : 1;?>          
                                                  <li class="page-item"><a href="?p=Judul<?= $link;?>&page=1" class="page-link">First</a> </li>          
                                                  <li class="page-item"><a href="?p=Judul<?= $link;?>&page=<?php echo $link_prev; ?>" class="page-link">&laquo;</a> </li>
                                                  <?php
                                              }

      // Hitung jumlah halamannya
                                              $jumlah_number = 5; 
      // Tentukan jumlah link number sebelum dan sesudah page yang aktif
                                              $start_number = ($data['page'] > $jumlah_number)? $data['page'] - $jumlah_number : 1; 
      // Untuk awal link number
                                              $end_number = ($data['page'] < ($data['jumlah_page'] - $jumlah_number)) ? $data['page'] + $jumlah_number : $data['jumlah_page'];

                                              for($i = $start_number; $i <= $end_number; $i++){
                                                $link_active = ($data['page'] == $i) ? ' active ' : ''; ?>
                                                <li class="page-item <?php echo $link_active; ?>"><a href="?p=Judul<?= $link;?>&page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a></li>        
                                                <?php 
                                            }
                                            ?>


                                            <!-- LINK NEXT AND LAST -->        
                                            <?php        
      // Jika page sama dengan jumlah page, maka disable link NEXT nya
      // Artinya page tersebut adalah page terakhir
                                            if($data['page'] == $data['jumlah_page']){ 
      // Jika page terakhir ?>
      <li class="page-item disabled"><a href="#" class="page-link">&raquo;</a></li>
      <li class="page-item disabled"><a href="#" class="page-link">Last</a></li>
      <?php 
  }else{ 
    // Jika Bukan page terakhir
    $link_next = ($data['page'] < $data['jumlah_page'])? $data['page'] + 1 : $data['jumlah_page'];?>
    <li class="page-item"><a href="?p=Judul<?= $link;?>&page=<?php echo $link_next; ?>" class="page-link">&raquo;</a></li>
    <li class="page-item"><a href="?p=Judul<?= $link;?>&page=<?php echo $data['jumlah_page']; ?>" class="page-link">Last</a></li>
    <?php } 
    ?>
</ul>
</div>
</div>
</div>

</div>
</div>
