<div class="row">
    <div class="col-md-12 col-xs-12">
        <?php 
        if($sess->get('level') == 1){?>
        <h2>
            <a href="?p=Dosen&x=Tambah" class="btn btn-outline-success"><strong> <i class="fa fa-user-plus"></i> Tambah Dosen</strong></a>
            <a href="" class="btn btn-outline-info"><strong> <i class="fa fa-user-plus"></i> Import Data Excel </strong></a>
        </h2>
        <?php } ?>
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><strong><?= $data['sub_title'];?></strong></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                <table id="dtskripsi" border="0" class="table table-bordered table-sm table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Alamat</th>
                            <th>No Hp</th>
                            <th width="100">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no=1;
                        for($i=0; $i<count($data['dosen']); $i++) {
                        ?>
                        <tr>
                            <td><?=$no?></td>
                            <td><?=$data['dosen'][$i]['Name']?></td>
                            <td><?=$data['dosen'][$i]['Email']?></td>
                            <td><?=$data['dosen'][$i]['Alamat1']?></td>
                            <td><?=$data['dosen'][$i]['Phone']?></td>
                            <td align="center">
                                <a href="?p=Dosen&x=Detail&id=<?= $data['dosen'][$i]['ID'] ?>" class="btn btn-outline-warning btn-sm"> <i class="fa fa-eye" aria-hidden></i> </a>
                                <?php
                                if($sess->get('level') == 1){ ?>
                                <a href="?p=Dosen&x=Edit&id=<?= $data['dosen'][$i]['ID'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> </a>
                                <a href="?p=Dosen&x=Hapus&id=<?= $data['dosen'][$i]['ID'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Yakin akan menghapus dosen ini?')"> <i class="fa fa-remove" aria-hidden></i> </a>
                                <?php } ?>
                            </td>
                        </tr>
                        <?php $no++; } ?>
                    </tbody>
                </table>
            </div>
            </div>
            <div class="card-footer">

            </div>
        </div>
    </div>
</div>