<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?= $data['sub_title'];?></h5>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-widget="collapse">
        <i class="fa fa-minus"></i>
      </button>
      <button type="button" class="btn btn-tool" data-widget="remove">
        <i class="fa fa-times"></i>
      </button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <div class="row">
      <div class="col-sm-12 col-md-6">
        <table class="table table-sm">
          <tr>
            <th>NIDN</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['NIDN'] ;?></td>
          </tr>
          <tr>
            <th>NIK</th>
             <td>:</td>
            <td><?= $data['dosen'][0]['NIK'] ;?></td>
          </tr>
          <tr>
            <th>Name</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['Name'].", ".$data['dosen'][0]['Gelar'] ;?></td>
          </tr>
          <tr>
            <th>Jenis Kelamin</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['Sex'] == 'L' ? 'Laki-laki' : 'Perempuan' ;?></td>
          </tr>
          <tr>
            <th>Tanggal Lahir</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['TglLahir'] ;?></td>
          </tr>
          <tr>
            <th>Tempat Lahir</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['TempatLahir'] ;?></td>
          </tr>          
        </table>
      </div>
      <div class="col-sm-12 col-md-6">
        <table class="table table-sm">
          <tr>
            <th>Alamat</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['Alamat1'] ;?></td>
          </tr>
          <tr>
            <th>Email</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['Email'] ;?></td>
          </tr>
          <tr>
            <th>No. Telepon</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['Phone'] ;?></td>
          </tr>
          <tr>
            <th>Jenjang Pendidikan</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['JenjangDosen'] ;?></td>
          </tr>
          <tr>
            <th>Lulusan PT</th>
            <td>:</td>
            <td><?= $data['dosen'][0]['LulusanPT'] ;?></td>
          </tr>
          <tr>
            <td colspan="3" align="center">
              <?php 
              if($sess->get('level')){?>
                <a href="?p=Dosen&x=Edit&id=<?= $data['dosen'][0]['ID'];?>" class="btn btn-info btn-flat">Edit</a>
                <a href="?p=Dosen&x=Hapus&id=<?= $data['dosen'][0]['ID'];?>" class="btn btn-danger btn-flat" onclick="return confirm('Yakin akan menghapus dosen ini?')">Hapus</a>
                <?php } ?>
              <a href="?p=Dosen" class="btn btn-dark btn-flat">Kembali</a>
            </td>
          </tr>
        </table>
      </div>
    </div>
  </div>
</div>