<div class="row">
    <div class="col-md-12 col-xs-12">
        <h2>
            <a href="?p=Judul&x=Pengajuan" class="btn btn-outline-success"> <i class="fa fa-plus"></i> Tambah Judul Baru</a>
            <a href="?p=Judul&x=Offline" class="btn btn-outline-dark"> <i class="fa fa-plus"></i> Tambah Judul Offline</a>
            <a href="?p=Judul&x=Pengajuan" class="btn btn-outline-primary"> <i class="fa fa-plus"></i> Pengajuan</a>
            <a href="?p=Judul&x=Diterima" class="btn btn-outline-info"> <i class="fa fa-eye"></i> Diterima</a>
            <a href="?p=Judul&x=Ditolak" class="btn btn-outline-danger"> <i class="fa fa-eye"></i> Ditolak</a>
            <a href="?p=Judul&x=Ditolak" class="btn btn-warning"> <i class="fa fa-gear"></i> Sistem Komputer</a>
            <a href="?p=Judul&x=Ditolak" class="btn btn-info"> <i class="fa fa-laptop"></i> Sistem Informasi</a>
        </h2>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title"> <strong> <i class="fa fa-file"></i> Semua Judul Skripsi</strong></h3>
            </div>
            <div class="card-body">
                <table id="dtskripsi" class="table-responsive table" border="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Prodi</th>
                            <th>Judul</th>
                            <th>Bahasa</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        for ($i = 0; $i < count($data); $i++) {
                            ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>
                                    <a href="?p=Judul&x=Detail&id=<?= $data[$i]['id'] ?>" class="btn btn-success btn-sm"> <?= $data[$i]['nim'] ?> </a>
                                </td>
                                <td><?= $data[$i]['prodi'] ?></td>
                                <td><?= $data[$i]['judul'] ?></td>
                                <td><?= $data[$i]['bahasa'] ?></td>
                                <td class="text-bold"><?= $data[$i]['status'] ?></td>
                                <td>
                                    <a href="?p=Judul&x=Ubah&id=<?= $data[$i]['id'] ?>" class="btn btn-outline-success btn-sm"> <i class="fa fa-edit" aria-hidden></i> </a>
                                    <a href="?p=Judul&x=Hapus&id=<?= $data[$i]['id'] ?>" class="btn btn-outline-danger btn-sm"> <i class="fa fa-remove" aria-hidden></i> </a>
                                </td>
                            </tr>
                            <?php $no++;
                        }
                        ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>
</div>