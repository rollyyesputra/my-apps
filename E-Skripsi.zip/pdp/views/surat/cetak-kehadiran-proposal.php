<?php 
if($sess->get('prodi')=="SI"){                  
	$prodi = "Sistem Informasi";
	$kpd = "William Ramdhan, M.Kom.";
	$NIDN ="0130048702";
	$homepage = "s1is.stmik.royal.ac.id";
	$email = "prodi_si@royal.ac.id";
	$logo = "../../gambar/si.png";
}else{ 
	$prodi = "Sistem Komputer";
	$kpd = "Muhammad Amin, M.Kom.";
	$NIDN ="0113128502";
	$homepage = "s1cs.stmik.royal.ac.id";
	$email = "prodi_sk@royal.ac.id";
	$logo = "../../gambar/sk.png";
}
?>

      <table width="100%">
        <tr>
         <td rowspan="" width="60">
          <?php            
          if($sess->get('prodi')=="SI"){
           ?>
           <img src="images/si.png" width="80" height="80"/>
           <?php }else{ ?>
             <img src="images/sk.png" width="80" height="80"/>
             <?php } ?>
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $sess->get('prodi') ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>KARTU KEHADIRAN SEMINAR PROPOSAL SKRIPSI</u></strong></td>
      </tr>
    </table>
    <!-- end head surat -->
    <br/>
							<div style="padding:0 20px; font-size:14px;">
							<table>
								<tr>
									<td width="100px">Nama</td>
									<td>:</td>
									<td><?= $data['row'][0]['Name'];?></td>
								</tr>
								<tr>
									<td>NIM</td>
									<td>:</td>
									<td><?= $data['row'][0]['NIM'];?></td>
								</tr>
								<tr>
									<td>Program Studi</td>
									<td>:</td>
									<td><?= $data['row'][0]['KodeJurusan'] =='SI'?'Sistem Informasi' : 'Sistem Komputer' ;?></td>
								</tr>
							</table>
						</div>
						<br/>
							<div style="padding:0 20px; font-size:14px;">
							<table border="1" cellpadding="2" cellspacing="0.2" width="100%">
								<thead>
									<tr>
										<th height="22px"><center>No.</center></th>
										<th><center>Tanggal</center></th>
										<th><center>Nama Penyaji</center></th>
										<th width="250px"><center>Judul Proposal</center></th>
										<th width="100px"><center>TTD Tim Penguji Seminar</center></th>
									</tr>
								</thead>
								<tbody>
									<?php for ($i = 0; $i < 20; $i++) {
										echo "<tr>
										<td height='22px'></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										</tr>";
									} ?>
								</tbody>
							</table>
						</div>
						<span style="font-size: 10pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*) Minimal 5 Kali Menjadi Peserta Seminar</span>