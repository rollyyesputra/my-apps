<?php 
if($data['undangan'][0]['KodeJurusan']=="SI"){                  
	$prodi = "Sistem Informasi";
	$kpd = "William Ramdhan, M.Kom.";
	$NIDN ="0130048702";
	$homepage = "s1is.stmik.royal.ac.id";
	$email = "prodi_si@royal.ac.id";
	$logo = "images/si.png";
}else{ 
	$prodi = "Sistem Komputer";
	$kpd = "Muhammad Amin, M.Kom.";
	$NIDN ="0113128502";
	$homepage = "s1cs.stmik.royal.ac.id";
	$email = "prodi_sk@royal.ac.id";
	$logo = "images/sk.png";
}
?>

      <table width="100%">
        <tr>
         <td rowspan="" width="60">          
           <img src="<?= $logo ;?>" width="80" height="80"/>           
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $prodi ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>SURAT UNDANGAN SEMINAR PROPOSAL SKRIPSI</u></strong></td>
      </tr>
    </table>
    <br/>
     <table>
      <tr>
            <td colspan="3" align="justify" style="padding: 0 20px; font-size: 14px">
              <br/>
              <p class="isi">
                Kepada Yth.
                <br/>
                Ketua Program Studi <?= $prodi ;?>
                <br/>
                Di
                <br/>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                Tempat, 
              </p>
              <p class="isi">
                Dengan Hormat, <br/>
                Dengan ini kami mengundang Bapak/Ibu untuk dapat hadir pada Acara Seminar Proposal Skripsi yang diadakan pada:
              </p>
              <table style="margin-left: 25px; font-size: 14px;" width="100%">
                <tr>
                  <td width="10%">Tanggal</td>
                  <td width="2%">:</td>
                  <td><?= $data['undangan'][0]['Tanggal'];?></td>
                </tr>
                <tr>
                  <td>Jam</td>
                  <td>:</td>
                  <td><?= $data['undangan'][0]['Jam'];?></td>
                </tr>
                <tr>
                  <td>Tempat</td>
                  <td>:</td>
                  <td><?= $data['undangan'][0]['Ruang'];?></td>
                </tr>
              </table>
              <p>Dalam hal ini Bapak/Ibu bertugas sebagai Dosen Pembimbing/Ketua Penguji/ Anggota Penguji * pada seminar proposal mahasiswa :</p>
              <table width="100%" border="1">
                <tr rowspan='2'>
                  <td>No.</td>
                  <td>NIM & Nama</td>
                  <td>Ketua Penguji</td>
                  <td>Dosen Pembimbing</td>
                  <td>Dosen Penguji</td>
                </tr>
                <tr>
                  <td rowspan="2">1</td>
                  <td rowspan="2"><?= $data['undangan'][0]['NIM'];?><br/><?= $data['undangan'][0]['Name'];?></td>
                  <td rowspan="2"><?= $data['undangan'][0]['Ketua'];?></td>
                  <td>1.<?= $data['undangan'][0]['Dosen1'];?></td>
                  <td>1.<?= $data['undangan'][0]['Penguji1'];?></td>
                </tr>
                <tr>
                  <td>2.<?= $data['undangan'][0]['Dosen2'];?></td>
                  <td>2.<?= $data['undangan'][0]['Penguji2'];?></td>
                </tr>
              </table>
              <br/>
              <p>
                Demikian undangan ini kami sampaikan, atas perhatian dan kehadirannya diucapkan banyak terima kasih.
              </p>
            </td>
          </tr>
          <tr>
    <!-- tanda tangan -->
    <td colspan="3">
      <div style="font-size: 14px;">

       <br/>
       <p style="float:right; margin-right:5px; width:300px; text-align:center;">
        <!-- Menyetujui, <br/><strong>Wakil Ketua 1</strong> -->
        Kisaran, <?= date('d-M-Y');?><br/>
        <br/><strong><span style="margin-right: 5px">Ka. Prodi</span></strong>
        <br/>
        <br/>
        <br/>
        <br/>
        <strong><u><?= $kpd ;?></u><br/>
          NIDN: <?= $NIDN ;?></strong>
        </p>
      </div>
    </td>
    <!-- akhir tanda tangan -->
  </tr>
  <tr>
    <td colspan="3" style="font-size: 9pt; font-style: italic;">
      Ket: *) Coret yang tidak perlu
    </td>
  </tr>
        </table>