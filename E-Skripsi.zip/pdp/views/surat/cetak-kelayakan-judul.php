<?php 
if($sess->get('prodi')=="SI"){                  
  $prd = "Sistem Informasi";
  $kpd = "William Ramdhan, M.Kom.";
  $NIDN ="0130048702";
  $homepage = "s1is.stmik.royal.ac.id";
  $email = "prodi_si@royal.ac.id";
}else{ 
  $prd = "Sistem Komputer";
  $kpd = "Muhammad Amin, M.Kom.";
  $NIDN ="0113128502";
  $homepage = "s1cs.stmik.royal.ac.id";
  $email = "prodi_sk@royal.ac.id";
}
?>

<table border="0" width="100%">
  <tr>
    <td colspan="3">
      <!-- head surat -->
      <table width="100%">
        <tr>
         <td rowspan="" width="60">
          <?php            
          if($sess->get('prodi')=="SI"){
           ?>
           <img src="images/si.png" width="80" height="80"/>
           <?php }else{ ?>
             <img src="images/sk.png" width="80" height="80"/>
             <?php } ?>
           </td>
           <td colspan="0" align="center" style="font-size: 14pt">Sekolah Tinggi Manajemen Informatika dan Komputer Royal
            <h4><b>STMIK ROYAL</b></h4>
            Program Studi <?= $prd ;?>
          </td>
          <td rowspan="" align="right">
           <img src="images/lpm-stmik-royal.png" width="80" height="80"/>         
         </td>
       </tr>
       <tr>
         <td colspan="3" align="center" style="font-size: 10pt">
          Jln. Prof. H.M Yamin, SH No. 173 Kisaran, Telp. (0623) 41079, Ext. 108 Lt.2 Kisaran, Kab. Asahan, Prov. Sumatera Utara <br/>
          Website: www.stmik.royal.ac.id, Homepage: <?= $homepage ;?>, Email: <?= $email ;?></td>
        </tr>
        <tr>
         <td colspan="3" style="border-bottom:3px solid black;"></td>
       </tr>
       <tr>
        <td colspan="8">
          <p style="float:right;">
          </p>
        </td>
      </tr>
      <tr>
        <td colspan="8" align="center"> <strong style="font-size:16px;"><u>LEMBAR PERNYATAAN KELAYAKAN JUDUL SKRIPSI</u></strong></td>
      </tr>
    </table>
    <!-- end head surat -->
  </td>
</tr>
</table>
<table>
  <tr>
    <td colspan="3" align="justify" style="padding: 0 20px;">
      <p class="isi">
        Dengan ini kami menyatakan bahwa judul/tema skripsi :
      </p>
      <p class="isi">
        <b><?php echo $data['judul'][0]['judul'] ;?></b>
      </p>
      <p class="isi">
        Yang diajukan oleh mahasiswa :              
        <table width="100%">
          <tr>
            <td style="font-size: 14px;">Nama</td>
            <td style="font-size: 14px;">:</td>
            <td style="font-size: 14px;"><?php echo $data['judul'][0]['Name']; ?></td>
          </tr>
          <tr>
            <td style="font-size: 14px;">NIM</td>
            <td style="font-size: 14px;">:</td>
            <td style="font-size: 14px;"><?php echo $data['judul'][0]['NIM'];?></td>
          </tr>
          <tr>
            <td style="font-size: 14px;" width="120px">Program Studi</td>
            <td style="font-size: 14px;">:</td>
            <td style="font-size: 14px;"><?php echo $data['judul'][0]['prodi'] == 'SI' ? 'Sistem Informasi' : 'Sistem Komputer' ;?></td>
          </tr>
          <?php if($data['judul'][0]['status'] == "SUDAH ACC"){ ?>
            <tr>
              <td style="font-size: 14px; vertical-align: top;" width="160px">Dinyatakan layak untuk </td>
              <td style="font-size: 14px; vertical-align: top;"> : </td>
              <td style="font-size: 14px;">
                <?php if(empty($data['judul'][0]['comment'])){?>
                  Dilanjutkan ke Seminar Proposal
                  <?php }else{ ?>
                    Dilanjutkan ke Seminar Proposal, dengan catatan:<br/>
                    <?php echo $data['judul'][0]['comment'] ;?>
                  </td>
                </tr>
                <?php } ?>
                <?php }elseif($data['judul'][0]['status'] == 'SUDAH DITOLAK'){ ?>
                  <tr>
                    <td style="font-size: 14px;">Dinyatakan </td>
                    <td style="font-size: 14px;">:</td>
                    <td style="font-size: 14px;">
                    Tidak layak dan harus diganti judul/tema baru</td>
                  </tr>
                  <?php } ?>
                </table>
              </p>
            </td>
          </tr>
          <tr>
            <td colspan="3" style="padding : 0 20px;">
              <br/><br/><br/><br/>
              <table width="100%">              
                <tr>
                  <td style="float: left; font-size: 14px;">
                    <p>
                      <!-- Menyetujui, <br/><strong>Wakil Ketua 1</strong> -->
                      <br/>
                      <br/>Pembimbing Skripsi 1,
                      <br/>
                      <br/>
                      <br/>
                      <br/>
                      <br/>
                      <br/>
                      <strong><u><?= $data['judul'][0]['Dosen1'] ;?></u><br/>
                        NIDN: <?= $data['judul'][0]['NIDN'] ;?></strong>
                      </p>
                    </td>
                    <td style="float: right; font-size: 14px;">
                      <p>
                        <!-- Menyetujui, <br/><strong>Wakil Ketua 1</strong> -->
                        Kisaran, <?php echo date('d-M-Y') ;?><br/>
                        <br/>Ka. Prodi
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <strong><u><?= $kpd ;?></u><br/>
                          NIDN: <?= $NIDN ;?></strong>
                        </p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td colspan="3" style="font-size: 10pt">
                  <hr size="1">
                  Dicetak Melalui Skripsi Online STMIK ROYAL Oleh <?php echo $sess->get('name') ?>  <br/>
                  <strong>
                   Pada
                   <?php
                   echo ' Tanggal '.date('d-m-Y').", Jam ";
                   echo gmdate("H:i:s", time()+60*60*7)." WIB";
                   ?>
                 </strong>
                 <br/><br/>
                 &COPY;<?php echo date("Y"); ?> STMIK ROYAL Kisaran
               </td>
             </tr>
           </table>