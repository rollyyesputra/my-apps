      <div class="card">
        <div class="card-header">
          <h5 class="card-title"><?= $data['sub_title'];?></h5>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse">
              <i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-widget="remove">
              <i class="fa fa-times"></i>
            </button>
          </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
          <?php 
          if($data['row']){ ?>
            <div class="row">
              <div class="col-sm-12 col-md-7">
                <form action="?p=Pembimbing&x=UpdatePembimbing" method="post">
                  <input type="hidden" name="IDP" value="<?= $data['row'][0]['IDPembimbing'];?>">
                  <input type="hidden" name="page" value="1">
                  <div class="form-group">
                    <label>NIM</label>
                    <input type="text" name="NIM" class="form-control" value="<?= $data['row'][0]['NIM'] ;?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="Name" class="form-control" value="<?= $data['row'][0]['Name'] ;?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Dosen 1</label>
                    
                    <select name="IDDosen1" class="form-control" required="">
                      <option value="">-Pilih Dosen-</option>
                      <?php
                      foreach ($data['dosen'] as $row) {
                        $data['row'][0]['IDDosen1'] == $row['ID'] ? $s='selected' : $s='';
                        echo "<option value='".$row['ID']."' $s>$row[NamaDosen]</option>";
                      }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Dosen 2</label>
                    
                    <select name="IDDosen2" class="form-control" required="">
                      <option value="">-Pilih Dosen-</option>
                      <?php
                      foreach ($data['dosen'] as $row) {
                        $data['row'][0]['IDDosen2'] == $row['ID'] ? $s='selected' : $s='';
                        echo "<option value='".$row['ID']."' $s>$row[NamaDosen]</option>";
                      }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-info btn-flat" value="Simpan">
                    <a href="?p=Pembimbing" class="btn btn-dark btn-flat">Batal</a>
                  </div>
                </form>
              </div>
            </div>
            <?php
          }else{ ?>
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?= $data['pesan'] ;?><br/>
              <a href="?p=Pembimbing">Kembali ke list pembimbing</a>
            </div>
            <?php }?>
          </div>
        </div>