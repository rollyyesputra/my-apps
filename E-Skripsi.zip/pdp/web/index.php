<?php
session_start();
// include '../config/Koneksi.php';
include '../config/DB.php';
include '../lib/ProcessDB.php';
include '../lib/Ethesis.php';
include '../lib/Session.php';
include '../lib/Controller.php';
include '../lib/Model.php';
include '../lib/View.php';
new Ethesis();

