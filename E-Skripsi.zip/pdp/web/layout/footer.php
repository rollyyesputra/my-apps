<hr/>
<div class="footer">
    <div class="container">
      <div class="alert alert-info">
        <span class="badge"> <strong>Ucapan Terima Kasih</strong> </span> <br>
        Terima kasih kepada Kementrian Riset dan Pendidikan Tinggi Republik Indonesia yang sudah mendanai penelitian untuk pembuatan aplikasi e-skripsi ini.
      </div>
      STMIK Royal Kisaran <br>
      Jln. Prof. H. M. Yamin, SH. No. 173 Kisaran - Sumatera Utara
      <hr>
    	&COPY; <?= date('Y') ?> <a href="#">  <span class="badge">E-Skripsi</span> </a> STMIK Royal Kisaran.
    </div>
</div>

<script src="../vendor/js/jQuery-2.1.4.min.js" type="text/javascript"></script>
<script src="../vendor/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../vendor/js/app.min.js" type="text/javascript"></script>
<script src="../vendor/plugins/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="../vendor/plugins/datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script>
  $(function () {
      $("#dtthesis").dataTable();
  });
</script>
</body>
</html>
