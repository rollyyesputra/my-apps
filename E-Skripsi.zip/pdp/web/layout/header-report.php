<?php $sess = new Session ;?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> <?=Ethesis::getTitle()?> | Skripsi Online STMIK Royal</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="shortcut icon" href="./images/SOP.jpg">
  <link rel="stylesheet" href="../vendor/AdminLTE-3/plugins/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../vendor/AdminLTE-3/dist/css/adminlte.min.css">
  <link href="../vendor/css/paper.css" rel="stylesheet" type="text/css"/>
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <style type="text/css">
    body{
      font-size: 12pt;
      font-family: "Aria";
      color: #000;
    }
  </style>
  <style>@page { size: A4 }</style>
</head>
<!-- Set "A5", "A4" or "A3" for class name -->
<!-- Set also "landscape" if you need -->
<?php 
if(empty($data2['class'])){
  $class ='A4auto';
}else {
  $class = $data2['class'];
}?>
    <body onload="print()" class="<?= $class ;?>">
      <section class="sheet padding-10mm">
