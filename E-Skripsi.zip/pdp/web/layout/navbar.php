<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
  <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="?p=index"> <strong>e-Skripsi</strong> </a>
  </div>
  <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav">
    <li><a href="#"> <strong>Home</strong> </a></li>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <strong>Data</strong> <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="?p=Mahasiswa">Mahasiswa</a></li>
          <li><a href="#">Another action</a></li>
          <li><a href="#">Something else here</a></li>
          <li role="separator" class="divider"></li>
          <li class="dropdown-header">Nav header</li>
          <li><a href="#">Separated link</a></li>
          <li><a href="#">One more separated link</a></li>
        </ul>
    </li>

    <li><a href="#about"> <strong>About</strong> </a></li>
    <?php if(@$_SESSION['level']==1){?>
      <li><a href="?page=contact">  <strong>Contact</strong> </a></li>
    <?php } ?>

    <li><a href="#"> <strong>Mahasiswa</strong> </a></li>
    <li><a href="?p=Kecamatan"> <strong>Pembimbing</strong> </a></li>
    <li><a href="#contact"> <strong>Kode Etik</strong> </a></li>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <strong>Master</strong> <span class="caret"></span></a>
        <ul class="dropdown-menu">
      <li><a href="#">Action</a></li>
      <li><a href="#">Another action</a></li>
      <li><a href="#">Something else here</a></li>
      <li role="separator" class="divider"></li>
      <li class="dropdown-header">Nav header</li>
      <li><a href="#">Separated link</a></li>
      <li><a href="#">One more separated link</a></li>
        </ul>
    </li>

      </ul>

      <ul class="nav navbar-nav navbar-right">
        <?php if(@$_SESSION['nama']==""){ ?>
          <li><a href="?page=login"> <strong>Login <i class="fa fa-unlock-alt" aria-hidden></i> </strong> </a></li>
        <?php }else{ ?>
          <li><a href="#"><strong style="color:yellow;"><?=@$_SESSION['nama']?></strong></a></li>
          <li><a href="?page=login&action=logout"> <strong>Logout <i class="fa fa-key" aria-hidden></i> </strong> </a></li>
        <?php } ?>
      </ul>
  </div>
    </div>
</nav>
