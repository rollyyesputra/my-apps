<li class="nav-item">
                                    <a href="?p=index" class="nav-link">
                                        <i class="nav-icon fa fa-dashboard"></i>
                                        <p>
                                            Dashboard
                                        </p>
                                    </a>
                                </li>
                                <!-- data dosen -->
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa fa-briefcase text-danger"></i>
                                        <p>
                                            Master Data
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Mahasiswa&x=mahasiswaaktif" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Mahasiswa Aktif</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-book text-danger"></i>
                                        <p>
                                            Judul Skripsi SI
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=si" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Semua Judul</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=si&thn=&sts=proses" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diproses</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=si&thn=&sts=terima" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diterima</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=si&thn=&sts=tolak" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Ditolak</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-book text-danger"></i>
                                        <p>
                                            Judul Skripsi SK
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=sk" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Semua Judul</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=sk&thn=&sts=proses" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diproses</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=sk&thn=&sts=terima" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Diterima</p>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="?p=Judul&x=JudulProdi&prodi=sk&thn=&sts=tolak" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Judul Ditolak</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                            <a href="?p=Judul&x=JudulRekomendasiDosen" class="nav-link">
                                                <i class="nav-icon fa fa-share-alt text-danger"></i> 
                                                <p>
                                                  Rekomendasi Judul
                                             </p>
                                            </a>
                                        </li>
                                <li class="nav-item has-treeview">
                                    <a href="#" class="nav-link">
                                        <i class="nav-icon fa fa-pie-chart text-danger"></i>
                                        <p>
                                            Pembimbing Skirpsi
                                            <i class="right fa fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
                                            <a href="?p=Pembimbing&x=BimbinganDosen" class="nav-link">
                                                <i class="fa fa-circle-o nav-icon"></i>
                                                <p>Data Bimbingan</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
    <a href="?p=User&x=ProfilDosen" class="nav-link">
        <i class="nav-icon fa fa-gears text-danger"></i>
        <p>
            Edit Profil
        </p>
    </a>
</li>