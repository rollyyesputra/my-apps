<?php

class DB {
    public static $engine="mysql";
    public static $host="localhost";
    public static $user="root";
    public static $pass="root";
    public static $dbname="pdp";
    
    // public static $db=array(
    //   "mysql:host=localhost;dbname=pdp","root","root"
    // );
}
