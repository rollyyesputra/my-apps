<?php

//konfigurasi path untuk website
define("PATH","http://localhost/pdp/");
define("SITE_URL",PATH."web/index.php");
define("HOME",PATH."?p=index");
