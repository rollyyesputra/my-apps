<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Konfigurasi
 *
 * @author rolly
 */
class Konfigurasi extends Model {
    public function delete($where = null, $page = null) {
        
    }

    public function edit($field = null, $where = null, $page = null) {
        
    }

    public function find() {
        
    }

    public function findOne($rows, $where = null, $order = null, $limit = null) {
        
    }

    public function save($rows = null, $page = null) {
        
    }

    public function tabel() {
        
    }

//put your code here
}
